import { Telegraf, Markup } from 'telegraf';
import { config } from './config';
import { store } from './store';
import { createPixChargeForPurchase } from './pix';
import { canPerform, notRecentlyPerformed } from './utils/rateLimiter';

export const bot = new Telegraf(config.botToken);

// Admins logados via /login (sessão) — declarar UMA vez e antes de isAdmin
const runtimeAdmins = new Set<number>();

const inFlightPurchases = new Set<string>();

function isAdmin(telegramId: number) {
  return runtimeAdmins.has(telegramId) || config.adminUserIds.includes(String(telegramId));
}

function ensureAdmin(ctx: any): boolean {
  if (!isAdmin(ctx.from.id)) {
    ctx.reply('Você não é administrador.');
    return false;
  }
  return true;
}

bot.start(async (ctx) => {
  const user = store.getOrCreateUser(ctx.from.id, ctx.from.first_name || ctx.from.username || 'Usuário', ctx.from.username);
  try {
    const payload: any = (ctx as any).startPayload;
    if (typeof payload === 'string' && payload.startsWith('aff_')) {
      const code = payload.slice(4);
      const aff = store.findAffiliateByCode(code);
      if (aff) {
        store.setUserReferredBy(user.id, aff.id);
      }
    }
  } catch (_) {}
  console.log(`[DEBUG] /start chamado por ${ctx.from.id}`);
  await ctx.reply(
    `Olá, ${ctx.from.first_name} 👋 — escolha uma opção.`,
    Markup.inlineKeyboard([
      [Markup.button.callback('Comprar CC FULL', 'menu_comprar_tutorial')],
      [Markup.button.callback('Histórico de CC FULL Compradas', 'menu_historico')],
      [Markup.button.callback('Buscar Info CC', 'menu_buscar_info_cc')],
      [Markup.button.callback('Adicionar Saldo', 'menu_adicionar_saldo')],
      [Markup.button.callback('Tornar Afiliado', 'menu_afiliado')],
      [Markup.button.callback('Consultar Saldo', 'menu_consultar_saldo')],
      [Markup.button.callback('Entrar no Grupo', 'menu_entrar_grupo')],
      [Markup.button.callback('Mensagem para o Suporte', 'menu_suporte')]
    ])
  );
});

// Handlers para os botões inline do menu
bot.action('menu_comprar_tutorial', async (ctx) => {
  await safelyAnswerCb(ctx);
  // Chama o mesmo código de bot.hears('Comprar Tutorial')
  const tutorials = store.listAvailableTutorials();
  if (tutorials.length === 0) {
    await ctx.reply('Nenhum CC FULL disponível. Tente mais tarde.');
    return;
  }
  const buttons = tutorials.map(t => [Markup.button.callback(`${t.title} — R${t.price}`, `buy_${t.id}`)]);
  await ctx.reply('Selecione um CC FULL:', Markup.inlineKeyboard(buttons));
});

bot.action('menu_historico', async (ctx) => {
  await safelyAnswerCb(ctx);
  // Chama o mesmo código de bot.hears('Histórico de Tutoriais Comprados')
  const user = store.getOrCreateUser(ctx.from.id, ctx.from.first_name || ctx.from.username || 'Usuário', ctx.from.username);
  const purchases = store.listPurchasesByUser(user.id);
  if (purchases.length === 0) {
    await ctx.reply('Você ainda não tem compras.');
    return;
  }
  for (const p of purchases) {
    const t = store.getTutorialById(p.tutorial_id);
    const title = t ? t.title : '(CC FULL removido)';
    const parts = [`${title} — ${p.status} — ${p.created_at.toLocaleString()}`];
    const buttons = [];
    if (p.status === 'completed') {
      buttons.push(Markup.button.callback('Reenviar Conteúdo', `resend_${p.id}`));
    } else {
      buttons.push(Markup.button.callback('Aguardando pagamento', `noop_${p.id}`));
    }
    await ctx.reply(parts.join('\n'), buttons.length ? Markup.inlineKeyboard([buttons]) : undefined);
  }
});

bot.action('menu_adicionar_saldo', async (ctx) => {
  await safelyAnswerCb(ctx);
  // Chama o mesmo código de bot.hears('Adicionar Saldo')
  await ctx.reply('Escolha um valor para adicionar (mínimo R$10):', Markup.inlineKeyboard([
    [Markup.button.callback('R$10', 'add_10'), Markup.button.callback('R$20', 'add_20')],
    [Markup.button.callback('R$50', 'add_50'), Markup.button.callback('Outro Valor', 'add_other')]
  ]));
});

bot.action('menu_consultar_saldo', async (ctx) => {
  await safelyAnswerCb(ctx);
  // Chama o mesmo código de bot.hears('Consultar Saldo')
  const user = store.getOrCreateUser(ctx.from.id, ctx.from.first_name || ctx.from.username || 'Usuário', ctx.from.username);
  await ctx.reply(`Seu saldo atual é: R${user.saldo.toFixed(2)}.`);
});

bot.action('menu_entrar_grupo', async (ctx) => {
  await safelyAnswerCb(ctx);
  await ctx.reply('Clique para entrar:', Markup.inlineKeyboard([Markup.button.url('Grupo de Aviso', config.groupInviteLink)]));
});

bot.action('menu_suporte', async (ctx) => {
  await safelyAnswerCb(ctx);
  // Chama o mesmo código de bot.hears('Mensagem para o Suporte')
  await ctx.reply('Digite sua mensagem para o suporte:');
  pendingText.set(ctx.from.id, { type: 'support', createdAt: Date.now() });
});

bot.action('menu_buscar_info_cc', async (ctx) => {
  await safelyAnswerCb(ctx);
  await ctx.reply('Escolha uma opção:', Markup.inlineKeyboard([
    [Markup.button.callback('Buscar por Bin', 'search_bin')],
    [Markup.button.callback('Buscar por Nível', 'search_lvl')],
    [Markup.button.callback('Buscar por Bandeira', 'search_bandeira')],
    [Markup.button.callback('Buscar por Banco', 'search_banco')]
  ]));
});
bot.action('menu_afiliado', async (ctx) => {
  await safelyAnswerCb(ctx);
  const u = store.getOrCreateUser(ctx.from.id, ctx.from.first_name || ctx.from.username || 'Usuário', ctx.from.username);
  const aff = store.ensureAffiliate(u.id);
  let me: any;
  try { me = await ctx.telegram.getMe(); } catch (_) {}
  const botUser = me?.username ? me.username : 'seu_bot';
  const link = `https://t.me/${botUser}?start=aff_${aff.affiliate_code}`;
  await ctx.reply(`Seu link de afiliado:\n${link}\nEnvie sua chave PIX (telefone, email ou CPF/CNPJ) para cadastro.`);
  pendingText.set(ctx.from.id, { type: 'affiliate_pix', createdAt: Date.now() });
});

bot.action('search_bin', async (ctx) => {
  await safelyAnswerCb(ctx);
  await ctx.reply('Informe o BIN (6 dígitos):');
  pendingText.set(ctx.from.id, { type: 'search_bin', createdAt: Date.now() });
});

bot.action('search_lvl', async (ctx) => {
  await safelyAnswerCb(ctx);
  await ctx.reply('Informe o Nível (ex.: PLATINUM):');
  pendingText.set(ctx.from.id, { type: 'search_lvl', createdAt: Date.now() });
});

// Comando de login admin: /login <senha>
bot.command('login', async (ctx) => {
  const text = ctx.message.text;
  const match = text.match(/^\/login(?:@\w+)?\s+(.+)$/i);
  const provided = match ? match[1].trim() : '';
  if (!provided) return ctx.reply('Uso: /login <senha>');
  if (provided === config.adminLoginSecret) {
    runtimeAdmins.add(ctx.from.id);
    return ctx.reply('Login de administrador realizado com sucesso.');
  }
  return ctx.reply('Senha incorreta.');
});

// Diagnóstico rápido
bot.command('whoami', async (ctx) => {
  const is = isAdmin(ctx.from.id);
  await ctx.reply(`Você é admin? ${is ? 'Sim' : 'Não'}. Seu ID: ${ctx.from.id}`);
});

bot.command('whome', async (ctx) => {
  const u = store.getOrCreateUser(ctx.from.id, ctx.from.first_name || ctx.from.username || 'Usuário', ctx.from.username);
  const info = `Usuário: ${u.name}${u.username ? ` (@${u.username})` : ''}\nID: ${u.telegram_id}`;
  await ctx.reply(info);
});

bot.command('clear', async (ctx) => {
  const chatId = ctx.chat?.id;
  const startId = ctx.message?.message_id;
  if (chatId === undefined || startId === undefined) return;
  let deleted = 0;
  try { await ctx.telegram.unpinAllChatMessages(chatId); } catch (_) {}
  const batch = 200;
  const tryDelete = async (mid: number) => {
    try { await ctx.telegram.deleteMessage(chatId, mid); return true; } catch (_) {}
    try { await ctx.telegram.editMessageReplyMarkup(chatId, mid, undefined, undefined); } catch (_) {}
    try { await ctx.telegram.deleteMessage(chatId, mid); return true; } catch (_) {}
    return false;
  };

  async function sweep(from: number, direction: 1 | -1, limit: number) {
    let current = from;
    let failures = 0;
    while ((direction < 0 && current > limit) || (direction > 0 && current < limit)) {
      const ids: number[] = [];
      for (let i = 0; i < batch; i++) {
        const id = current + i * direction;
        if (direction < 0 ? id <= limit : id >= limit) break;
        ids.push(id);
      }
      const results = await Promise.allSettled(ids.map(mid => tryDelete(mid)));
      let ok = 0;
      for (const r of results) if (r.status === 'fulfilled' && r.value === true) ok++;
      deleted += ok;
      failures = ok === 0 ? failures + 1 : 0;
      if (failures >= 10) break;
      current += batch * direction;
    }
  }

  await sweep(startId, -1, 0);
  await sweep(startId + 1, 1, startId + 100000);
  try {
    const m = await ctx.reply(`Conversa limpa (${deleted} mensagens).`);
    setTimeout(async () => {
      try { await ctx.telegram.deleteMessage(chatId, m.message_id); } catch (_) {}
    }, 1500);
  } catch (_) {}
});

bot.hears('Consultar Saldo', async (ctx) => {
  const user = store.getOrCreateUser(ctx.from.id, ctx.from.first_name || ctx.from.username || 'Usuário', ctx.from.username);
  await ctx.reply(`Seu saldo atual é: R${user.saldo.toFixed(2)}.`);
});

async function ensureGroupMember(ctx: any): Promise<boolean> {
  try {
    const member = await ctx.telegram.getChatMember(config.groupChatId, ctx.from.id);
    const status = member.status;
    const isMember = ['member', 'administrator', 'creator'].includes(status);
    if (!isMember) {
      await ctx.reply(
        'Para comprar, você precisa ser membro do Grupo de Aviso. Clique para entrar.',
        Markup.inlineKeyboard([Markup.button.url('Entrar no Grupo', config.groupInviteLink)])
      );
    }
    return isMember;
  } catch (e) {
    await ctx.reply('Não consegui verificar sua membresia agora. Tente novamente em instantes.');
    return false;
  }
}

bot.hears('Comprar CC FULL', async (ctx) => {
  const tutorials = store.listAvailableTutorials();
  if (tutorials.length === 0) {
    await ctx.reply('Nenhum CC FULL disponível. Tente mais tarde.');
    return;
  }
  const buttons = tutorials.map(t => [Markup.button.callback(`${t.title} — R${t.price}`, `buy_${t.id}`)]);
  await ctx.reply('Selecione um CC FULL:', Markup.inlineKeyboard(buttons));
});

bot.action(/buy_(.+)/, async (ctx) => {
  await safelyAnswerCb(ctx);
  const tutorialId = ctx.match[1];
  if (store.hasGloballyPurchased(tutorialId)) {
    await ctx.reply('CC FULL indisponível.');
    return;
  }
  if (!(await ensureGroupMember(ctx))) return;

  const tutorial = store.getTutorialById(tutorialId)!;
  const buttons = [[Markup.button.callback(`Pagar com Saldo (R${tutorial.price})`, `saldo_${tutorialId}`)]];
  await ctx.editMessageText(
    `Opções para "${tutorial.title}":`,
    Markup.inlineKeyboard(buttons)
  );
});

bot.action(/saldo_(.+)/, async (ctx) => {
  await safelyAnswerCb(ctx);
  try {
    await ctx.editMessageReplyMarkup(undefined);
  } catch (_) {}

  const tutorialId = ctx.match[1];
  if (store.hasGloballyPurchased(tutorialId)) {
    await ctx.reply('CC FULL indisponível.');
    return;
  }
  const purchaseKey = `${ctx.from.id}:${tutorialId}`;

  if (inFlightPurchases.has(purchaseKey)) {
    await ctx.reply('Sua compra está sendo processada. Aguarde alguns instantes.');
    return;
  }
  inFlightPurchases.add(purchaseKey);

  try {
    const cooldownKey = `cooldown:purchase_saldo:${ctx.from.id}:${tutorialId}`;
    if (!notRecentlyPerformed(cooldownKey, 60_000)) {
      // silencioso: ignora reentradas dentro de 1 minuto
      return;
    }

    const user = store.getOrCreateUser(ctx.from.id, ctx.from.first_name || ctx.from.username || 'Usuário', ctx.from.username);
    const tutorial = store.getTutorialById(tutorialId)!;

    const alreadyBought = store
      .listPurchasesByUser(user.id)
      .find(p => p.tutorial_id === tutorialId && p.status === 'completed');
    if (alreadyBought) {
      // silencioso: evita mensagem repetida logo após a compra
      return;
    }

    if (user.saldo < tutorial.price) {
      await ctx.reply('Saldo insuficiente. Use "Adicionar Saldo" para recarregar.');
      return;
    }

    store.addSaldo(user.id, -tutorial.price);

    const purchase = await store.createPurchase({
      userId: user.id, tutorialId, price: tutorial.price, method: 'saldo'
    });

    // não chama setPurchaseCompleted para saldo (já nasce como completed)

    await ctx.reply('Pagamento confirmado ✅ — revelando seu texto secreto...');
    for (const chunk of splitContent(tutorial.content)) {
      await ctx.reply(chunk);
    }
  } finally {
    inFlightPurchases.delete(purchaseKey);
  }
});

bot.action(/pix_(.+)/, async (ctx) => {
  await safelyAnswerCb(ctx);
  try {
    await ctx.editMessageReplyMarkup(undefined);
  } catch (_) {}

  const tutorialId = ctx.match[1];
  if (store.hasGloballyPurchased(tutorialId)) {
    await ctx.reply('CC FULL indisponível.');
    return;
  }
  const purchaseKey = `${ctx.from.id}:${tutorialId}`;

  // Guard contra processamento concorrente imediato
  if (inFlightPurchases.has(purchaseKey)) {
    await ctx.reply('Sua cobrança PIX está sendo processada. Aguarde alguns instantes.');
    return;
  }
  inFlightPurchases.add(purchaseKey);

  try {
    // Cooldown de 1 minuto
    const cooldownKey = `cooldown:purchase_pix:${ctx.from.id}:${tutorialId}`;
    if (!notRecentlyPerformed(cooldownKey, 60_000)) {
      // Bloqueio silencioso: não responder nada, apenas ignorar
      return;
    }

    const user = store.getOrCreateUser(ctx.from.id, ctx.from.first_name || ctx.from.username || 'Usuário', ctx.from.username);
    const tutorial = store.getTutorialById(tutorialId)!;

    const alreadyBought = store
      .listPurchasesByUser(user.id)
      .find(p => p.tutorial_id === tutorialId && p.status === 'completed');
    if (alreadyBought) {
      // Silencioso: não criar nova cobrança nem reenviar conteúdo
      return;
    }

    try {
      const { charge, purchase } = await createPixChargeForPurchase(String(ctx.from.id), tutorialId);
      const short_id = (await import('crypto')).default.createHash('sha256').update(String(purchase.external_id || '')).digest('hex').slice(0, 12);
      const qrcode = charge.qrcode || charge.copy_paste || charge.pix?.qrcode || (charge as any)?.raw?.qrcode || (charge as any)?.raw?.qr_code || (charge as any)?.raw?.qrCode || (charge as any)?.raw?.code || '';
      const secureUrl = (charge as any)?.raw?.secureUrl || (charge as any)?.raw?.secure_url || undefined;
      const text = `Foi gerado seu PIX copia e cola:\n` +
        (qrcode ? `${qrcode}\n` : '') +
        `Clique sobre o PIX copia e cola para copiar e fazer o pagamento.\nEsse código expira em 10 minutos.`;
      const keyboard = secureUrl
        ? Markup.inlineKeyboard([[
            Markup.button.url('Abrir página de pagamento', secureUrl),
            Markup.button.callback('Copiar código', `copy_qr_${short_id}`)
          ]])
        : Markup.inlineKeyboard([[
            Markup.button.callback('Copiar código', `copy_qr_${short_id}`)
          ]]);
      try {
        if (qrcode) {
          const QR = (await import('qrcode')).default;
          const buf = await QR.toBuffer(qrcode, { type: 'png', margin: 1 });
          await ctx.replyWithPhoto({ source: buf }, { caption: text, reply_markup: keyboard.reply_markup });
        } else if (charge.qr_code_base64) {
          const buf = Buffer.from(charge.qr_code_base64, 'base64');
          await ctx.replyWithPhoto({ source: buf }, { caption: text, reply_markup: keyboard.reply_markup });
        } else {
          await ctx.reply(text, keyboard);
        }
      } catch (_) {
        await ctx.reply(text, keyboard);
      }

      const secureId = (charge as any)?.raw?.secureId;
      setTimeout(async () => {
        try {
          const provider = (await import('./pix/provider')).pixProvider;
          const list = await provider.listTransactions();
          const match = Array.isArray(list) ? list.find((t: any) => t.secureId === secureId) : undefined;
          if (match) {
            const statusText = `Status da transação:\n` +
              `ID: ${match.id}\n` +
              `Valor: R$${(Number(match.amount)/100).toFixed(2)}\n` +
              `Método: ${match.paymentMethod}\n` +
              `Status: ${match.status}\n` +
              `secureId: ${match.secureId}\n` +
              (match.secureUrl ? `secureUrl: ${match.secureUrl}` : '');
            await ctx.reply(statusText);
          }
        } catch (_) {}
      }, 10000);
    } catch (e: any) {
      await ctx.reply('Falha ao criar cobrança PIX. Tente novamente mais tarde.');
    }
  } finally {
    inFlightPurchases.delete(purchaseKey);
  }
});

bot.hears('Adicionar Saldo', async (ctx) => {
  await ctx.reply('Escolha um valor para adicionar (mínimo R$10):', Markup.inlineKeyboard([
    [Markup.button.callback('R$10', 'add_10'), Markup.button.callback('R$20', 'add_20')],
    [Markup.button.callback('R$50', 'add_50'), Markup.button.callback('Outro Valor', 'add_other')]
  ]));
});

bot.action(/add_(\d+)/, async (ctx) => {
  await safelyAnswerCb(ctx);
  try {
    await ctx.editMessageReplyMarkup(undefined);
    await ctx.deleteMessage();
  } catch (_) {}

  const value = Number(ctx.match[1]);

  // Evitar múltiplas cobranças de saldo com o mesmo valor em sequência
  const addKey = `add_balance_quick:${ctx.from.id}:${value}`;
  if (!canPerform(addKey, 1)) {
    await ctx.reply('Já existe uma cobrança de saldo em andamento para este valor. Aguarde.');
    return;
  }

  const user = store.getOrCreateUser(ctx.from.id, ctx.from.first_name || ctx.from.username || 'Usuário', ctx.from.username);
  const external_id = `add_balance_${user.id}_${Date.now()}`;
  const short_id = (await import('crypto')).default.createHash('sha256').update(external_id).digest('hex').slice(0, 12);
  // Reutiliza provider diretamente:
  let charge: any;
  try {
    charge = await (await import('./pix/provider')).pixProvider.createCharge({
      external_id,
      amount: value,
      description: `Recarga Saldo`,
      metadata: { userId: user.id, username: user.username, telegramName: user.name }
    });
  } catch (err: any) {
    const raw = err?.response?.data?.message;
    let msg = 'Falha ao criar cobrança PIX.';
    if (typeof raw === 'string' && raw.includes('below the minimum allowed')) {
      msg = 'Valor abaixo do mínimo permitido pelo provedor. Tente R$10 ou mais.';
    }
    await ctx.reply(msg);
    return;
  }
  store.savePixPayment({ external_id, short_id, txid: charge.txid, amount: charge.amount, status: 'pending', provider_response: { ...charge, pix: { qrcode: charge.qrcode || charge.copy_paste || charge.pix?.qrcode } }, pix_qrcode: charge.qrcode || charge.copy_paste || charge.pix?.qrcode });
  {
    const qrcode = charge.qrcode || charge.copy_paste || charge.pix?.qrcode || (charge as any)?.raw?.qrcode || (charge as any)?.raw?.qr_code || (charge as any)?.raw?.qrCode || (charge as any)?.raw?.code || '';
    const secureUrl = (charge as any)?.raw?.secureUrl || (charge as any)?.raw?.secure_url || undefined;
    const text = `Foi gerado seu PIX copia e cola:\n` +
      (qrcode ? `${qrcode}\n` : '') +
      `Clique sobre o PIX copia e cola para copiar e fazer o pagamento.\nEsse código expira em 10 minutos.`;
    const keyboard = secureUrl
      ? Markup.inlineKeyboard([[
          Markup.button.url('Abrir página de pagamento', secureUrl),
          Markup.button.callback('Copiar código', `copy_qr_${short_id}`),
          Markup.button.callback('Já paguei', `check_paid_${short_id}`)
        ]])
      : Markup.inlineKeyboard([[
          Markup.button.callback('Copiar código', `copy_qr_${short_id}`),
          Markup.button.callback('Já paguei', `check_paid_${short_id}`)
        ]]);
    try {
      if (qrcode) {
        const QR = (await import('qrcode')).default;
        const buf = await QR.toBuffer(qrcode, { type: 'png', margin: 1 });
        await ctx.replyWithPhoto({ source: buf }, { caption: text, reply_markup: keyboard.reply_markup });
      } else {
        await ctx.reply(text, keyboard);
      }
    } catch (_) {
      await ctx.reply(text, keyboard);
    }

    const secureId = (charge as any)?.raw?.secureId;
    setTimeout(async () => {
      try {
        const provider = (await import('./pix/provider')).pixProvider;
        const list = await provider.listTransactions();
        const match = Array.isArray(list) ? list.find((t: any) => t.secureId === secureId) : undefined;
        if (match && String(match.paymentMethod).toLowerCase() === 'pix') {
          if (String(match.status).toLowerCase() === 'paid') {
            const userIdStr = external_id.split('_')[2];
            const user = store.getUserById(userIdStr);
            if (user) {
              const pmt = store.getPixPaymentByShortId(short_id);
              if (pmt && pmt.status === 'paid') {
                return;
              }
              if (pmt) {
                pmt.status = 'paid';
                pmt.paid_at = new Date();
                pmt.provider_response = match;
                store.savePixPayment(pmt);
              }
              const valueCredits = Number(match.amount) / 100;
              store.addSaldo(user.id, valueCredits);
              if (user.referred_by) {
                const aff = store.getUserById(user.referred_by);
                const percent = aff?.affiliate_percent ?? 5;
                const commission = valueCredits * (percent / 100);
                if (aff && commission > 0) {
                  store.addAffiliateCommission(aff.id, user.id, commission, percent);
                }
              }
              await ctx.reply(`Seu pix foi creditado com sucesso. Saldo atual: R$${user.saldo.toFixed(2)}.`);
            }
          } else {
            const statusText = `Status da transação:\n` +
              `ID: ${match.id}\n` +
              `Valor: R$${(Number(match.amount)/100).toFixed(2)}\n` +
              `Método: ${match.paymentMethod}\n` +
              `Status: ${match.status}`;
            await ctx.reply(statusText);
          }
        }
      } catch (_) {}
    }, 60000);
  }
});

bot.action('add_other', async (ctx) => {
  await safelyAnswerCb(ctx);
  try { await ctx.deleteMessage(); } catch (_) {}
  await ctx.reply('Informe o valor desejado (R$) — mínimo R$10:');
  pendingText.set(ctx.from.id, { type: 'add_balance', createdAt: Date.now() });
});

// Estado simples para capturar o próximo texto enviado pelo usuário
const pendingText = new Map<number, { type: 'add_balance' | 'support' | 'search_bin' | 'search_lvl' | 'search_bandeira' | 'search_banco' | 'affiliate_pix'; createdAt: number }>();
bot.action('search_bandeira', async (ctx) => {
  await safelyAnswerCb(ctx);
  await ctx.reply('Informe a Bandeira (ex.: VISA):');
  pendingText.set(ctx.from.id, { type: 'search_bandeira', createdAt: Date.now() });
});

bot.action('search_banco', async (ctx) => {
  await safelyAnswerCb(ctx);
  await ctx.reply('Informe o Banco (ex.: PORTOSEG):');
  pendingText.set(ctx.from.id, { type: 'search_banco', createdAt: Date.now() });
});

// Wizard de criação de tutorial (admin)
type TutorialWizardState = {
  step: 'title' | 'description' | 'price' | 'content';
  title?: string;
  description?: string;
  price?: number;
};
const pendingTutorial = new Map<number, TutorialWizardState>();
type AdminWizardState = {
  step: 'menu' | 'add_saldo_id' | 'add_saldo_value' | 'broadcast_msg' | 'refund_input' | 'edit_tutorial_field';
  data?: any;
};
const pendingAdmin = new Map<number, AdminWizardState>();

function splitContent(content: string, chunkSize = 3500): string[] {
  const chunks: string[] = [];
  for (let i = 0; i < content.length; i += chunkSize) {
    chunks.push(content.slice(i, i + chunkSize));
  }
  return chunks;
}

// Handler de texto duplicado removido. O handler abaixo gerencia todos os fluxos corretamente, chamando next() para comandos.

bot.hears('Histórico de CC FULL Compradas', async (ctx) => {
  const user = store.getOrCreateUser(ctx.from.id, ctx.from.first_name || ctx.from.username || 'Usuário', ctx.from.username);
  const purchases = store.listPurchasesByUser(user.id);
  if (purchases.length === 0) {
    await ctx.reply('Você ainda não tem compras.');
    return;
  }
  for (const p of purchases) {
    const t = store.getTutorialById(p.tutorial_id);
    const title = t ? t.title : '(CC FULL removido)';
    const parts = [`${title} — ${p.status} — ${p.created_at.toLocaleString()}`];
    const buttons = [];
    if (p.status === 'completed') {
      buttons.push(Markup.button.callback('Reenviar Conteúdo', `resend_${p.id}`));
    } else {
      buttons.push(Markup.button.callback('Aguardando pagamento', `noop_${p.id}`));
    }
    await ctx.reply(parts.join('\n'), buttons.length ? Markup.inlineKeyboard([buttons]) : undefined);
  }
});

bot.action(/resend_(.+)/, async (ctx) => {
  await safelyAnswerCb(ctx);
  const purchaseId = ctx.match[1];
  const key = `reissue:${ctx.from.id}`;
  if (!canPerform(key, Number(process.env.REISSUE_RATE_LIMIT_PER_HOUR || 3))) {
    await ctx.reply('Limite de reenvios atingido. Tente mais tarde.');
    return;
  }
  const p = store['purchases'].get(purchaseId);
  if (!p || p.status !== 'completed') return;
  const t = store.getTutorialById(p.tutorial_id)!;
  await ctx.reply('Reenvio do texto secreto:');
  for (const chunk of splitContent(t.content)) {
    await ctx.reply(chunk);
  }
});

bot.hears('Entrar no Grupo', async (ctx) => {
  await ctx.reply('Clique para entrar:', Markup.inlineKeyboard([Markup.button.url('Grupo de Aviso', config.groupInviteLink)]));
});

bot.hears('Mensagem para o Suporte', async (ctx) => {
  await ctx.reply('Digite sua mensagem para o suporte:');
  pendingText.set(ctx.from.id, { type: 'support', createdAt: Date.now() });
});

// Admin commands
bot.command('admin', async (ctx) => {
  if (!ensureAdmin(ctx)) return;
  pendingAdmin.set(ctx.from.id, { step: 'menu' });
  await showAdminMenu(ctx);
});

async function showAdminMenu(ctx: any) {
  await ctx.reply('Menu Admin - Escolha uma opção:', Markup.inlineKeyboard([
    [Markup.button.callback('Adicionar CC FULL', 'admin_add_tutorial')],
    [Markup.button.callback('Adicionar Saldo', 'admin_add_saldo')],
    [Markup.button.callback('Mostrar Afiliados', 'admin_affiliates')],
    [Markup.button.callback('Listar CC FULL', 'admin_list_tutorials')],
    [Markup.button.callback('Relatório de Vendas', 'admin_sales_report')],
    [Markup.button.callback('Broadcast', 'admin_broadcast')],
    [Markup.button.callback('Refund', 'admin_refund')],
  ]));
}

bot.action('admin_add_tutorial', async (ctx) => {
  await safelyAnswerCb(ctx);
  pendingTutorial.set(ctx.from.id, { step: 'title' });
  await ctx.reply('Vamos criar um novo CC FULL.\nInforme o Título:');
});

bot.action('admin_add_saldo', async (ctx) => {
  await safelyAnswerCb(ctx);
  pendingAdmin.set(ctx.from.id, { step: 'add_saldo_id' });
  await ctx.reply('Envie uma mensagem encaminhada do usuário OU digite @username ou o Telegram ID:');
});

// NOVO: handler do botão "Listar Tutoriais" no menu admin
bot.action('admin_list_tutorials', async (ctx) => {
  await safelyAnswerCb(ctx);
  if (!ensureAdmin(ctx)) return;

  const tutorials = store.listTutorials();
  if (tutorials.length === 0) {
    await ctx.reply('Nenhuma CC FULL.');
    return;
  }
  for (const t of tutorials) {
    const purchased = store.hasGloballyPurchased(t.id);
    const hasPrice = /\bR\$?\s?\d+(?:[.,]\d+)?\b/i.test(t.title);
    const text = `${t.id} — ${t.title}${hasPrice ? '' : ` — R${t.price}`}${purchased ? ' — JÁ COMPRADO' : ''}\n${t.description || ''}`;
    await ctx.reply(
      text,
      Markup.inlineKeyboard([
        [
          Markup.button.callback('Editar', `admin_edit_${t.id}`),
          Markup.button.callback('Remover', `admin_remove_${t.id}`)
        ]
      ])
    );
  }
});

bot.command('add_ccfull', async (ctx) => {
  if (!ensureAdmin(ctx)) return;
  pendingTutorial.set(ctx.from.id, { step: 'title' });
  await ctx.reply('Vamos criar um novo CC FULL.\nInforme o Título:');
});
bot.command('add_saldo', async (ctx) => {
  if (!ensureAdmin(ctx)) return;
  console.log(`[DEBUG] /add_saldo chamado por ${ctx.from.id} com args: ${ctx.message.text}`);
  try {
    const raw = ctx.message.text.replace('/add_saldo', '').trim();
    const parts = raw.split(/\s+/).filter(Boolean);
    let value: number | undefined;
    let resolvedId: number | undefined;

    if (Array.isArray((ctx.message as any)?.entities)) {
      const mention = (ctx.message as any).entities.find((e: any) => e.type === 'mention');
      if (mention) {
      const m = raw.slice(mention.offset, mention.offset + mention.length).replace(/^@/, '').trim();
      const u = store.getUserByQuery(m);
      if (u) resolvedId = u.telegram_id;
      }
    }

    const fwd = (ctx.message as any)?.forward_from;
    if (!resolvedId && fwd && typeof fwd.id === 'number') {
      resolvedId = Number(fwd.id);
    }

    if (!resolvedId) {
      const replyFrom = (ctx.message as any)?.reply_to_message?.from;
      if (replyFrom && typeof replyFrom.id === 'number') {
        resolvedId = Number(replyFrom.id);
      }
    }

    if (!resolvedId) {
      const m1 = raw.match(/@([\w_]+)/);
      const m2 = raw.match(/t\.me\/([\w_]+)/);
      const handle = (m1 && m1[1]) || (m2 && m2[1]);
      if (handle) {
        const u2 = store.getUserByQuery(handle);
        if (u2) resolvedId = u2.telegram_id;
      }
    }

    const nums = parts.map(p => Number(p)).filter(n => !Number.isNaN(n));
    if (resolvedId === undefined) {
      if (nums.length >= 2) {
        resolvedId = nums[0];
        value = nums[1];
      } else if (nums.length === 1) {
        value = nums[0];
      }
    } else {
      if (nums.length >= 1) {
        value = nums[nums.length - 1];
      }
    }

    if (resolvedId === undefined || value === undefined || value <= 0) {
      return ctx.reply('Uso: /add_saldo <@username|ID> <valor> — ou encaminhe uma mensagem do usuário e informe o valor.');
    }

    const user = store.getOrCreateUser(resolvedId, String(resolvedId));
    store.addSaldo(user.id, value);
    console.log(`[DEBUG] Saldo adicionado para ${resolvedId}: ${value}`);
      await ctx.reply(`Saldo creditado: R$${value}. Saldo atual: R$${user.saldo}.`);
    try {
    if (resolvedId !== ctx.from.id) {
      await ctx.telegram.sendMessage(resolvedId, `Saldo creditado: R$${value}. Saldo atual: R$${user.saldo}.`);
    }
    } catch (sendError: any) {
    console.log(`[DEBUG] Erro ao enviar mensagem para ${resolvedId}: ${sendError.message}`);
    await ctx.reply(`Saldo creditado, mas falha ao notificar o usuário: ${sendError.message}`);
    }
  } catch (error: any) {
    console.error(`[ERROR] Erro ao adicionar saldo: ${error.message}`);
    await ctx.reply('Ocorreu um erro ao processar o comando. Tente novamente.');
  }
});

// Tratar textos: wizard admin e outros fluxos
bot.on('text', async (ctx, next) => {
  const text = ctx.message?.text ?? '';

  // Não interceptar comandos: deixa seguir para bot.command(...)
  if (text.startsWith('/')) {
    return next();
  }

  // Wizard admin: criação de tutorial
  const w = pendingTutorial.get(ctx.from.id);
  if (w) {
    if (w.step === 'title') {
      w.title = text.trim();
      w.step = 'description';
      await ctx.reply('Informe a Descrição curta:');
      return;
    }
    if (w.step === 'description') {
      w.description = text.trim();
      w.step = 'price';
      await ctx.reply('Informe o Preço (apenas números, ex.: 20):');
      return;
    }
    if (w.step === 'price') {
      const price = Number(text.trim());
      if (Number.isNaN(price) || price <= 0) {
        await ctx.reply('Preço inválido. Informe um número maior que zero.');
        return;
      }
      w.price = price;
      w.step = 'content';
      await ctx.reply('Envie o Conteúdo (texto). Este conteúdo só será mostrado para quem comprar:');
      return;
    }
    if (w.step === 'content') {
      const content = text;
      const tut = store.addTutorial({
        title: w.title!,
        price: w.price!,
        description: w.description!,
        content,
        thumbnail: undefined
      });
      pendingTutorial.delete(ctx.from.id);
      await ctx.reply(`CC FULL criado: ${tut.title} (R${tut.price}) — ID: ${tut.id}`);
      return;
    }
  }

  // Wizard admin: outras opções
  const a = pendingAdmin.get(ctx.from.id);
  if (a) {
    if (a.step === 'add_saldo_id') {
      let resolvedId: number | undefined;

      const fwd = (ctx.message as any)?.forward_from;
      if (fwd && typeof fwd.id === 'number') {
        resolvedId = Number(fwd.id);
      }

      if (!resolvedId && Array.isArray((ctx.message as any)?.entities)) {
        const mention = (ctx.message as any).entities.find((e: any) => e.type === 'mention');
        if (mention) {
          const username = text.slice(mention.offset, mention.offset + mention.length).replace(/^@/, '').trim();
          const u = store.getUserByQuery(username);
          if (u) resolvedId = u.telegram_id;
        }
      }

      if (!resolvedId) {
        const replyFrom = (ctx.message as any)?.reply_to_message?.from;
        if (replyFrom && typeof replyFrom.id === 'number') {
          resolvedId = Number(replyFrom.id);
        }
      }

      if (!resolvedId) {
        const m1 = text.match(/@([\w_]+)/);
        const m2 = text.match(/t\.me\/([\w_]+)/);
        const handle = (m1 && m1[1]) || (m2 && m2[1]);
        if (handle) {
          const u = store.getUserByQuery(handle);
          if (u) resolvedId = u.telegram_id;
        }
      }

      if (!resolvedId) {
        const numeric = Number(text.trim());
        if (!Number.isNaN(numeric)) resolvedId = numeric;
      }

      if (!resolvedId) {
        await ctx.reply('Não consegui identificar o usuário. Encaminhe uma mensagem dele ou envie @username ou ID.');
        return;
      }

      a.data = { telegramId: resolvedId };
      a.step = 'add_saldo_value';
      await ctx.reply('Informe o valor a adicionar:');
      return;
    }
    if (a.step === 'add_saldo_value') {
      const value = Number(text.trim());
      if (Number.isNaN(value) || value <= 0) {
        await ctx.reply('Valor inválido. Informe um número maior que zero.');
        return;
      }
      const { telegramId } = a.data;
      const user = store.getOrCreateUser(telegramId, String(telegramId));
      store.addSaldo(user.id, value);
      await ctx.reply(`Saldo creditado: R$${value}. Saldo atual: R$${user.saldo}.`);
      try {
        if (telegramId !== ctx.from.id) {
          await ctx.telegram.sendMessage(telegramId, `Saldo creditado: R$${value}. Saldo atual: R$${user.saldo}.`);
        }
      } catch (sendError: any) {
        await ctx.reply(`Saldo creditado, mas falha ao notificar o usuário: ${sendError.message}`);
      }
      pendingAdmin.delete(ctx.from.id);
      await showAdminMenu(ctx);
      return;
    }
    if (a.step === 'broadcast_msg') {
      const msg = text.trim();
      if (!msg) {
        await ctx.reply('Mensagem vazia. Tente novamente.');
        return;
      }
      const chatId = Number(config.groupChatId);
      if (!chatId || Number.isNaN(chatId)) {
        await ctx.reply('GROUP_CHAT_ID inválido ou não configurado no .env.');
        pendingAdmin.delete(ctx.from.id);
        await showAdminMenu(ctx);
        return;
      }
      try {
        await ctx.telegram.sendMessage(chatId, `[Broadcast]: ${msg}`);
        await ctx.reply('Mensagem enviada ao grupo.');
      } catch (err: any) {
        const desc = err?.response?.description || err?.message || 'Erro desconhecido';
        await ctx.reply(`Falha ao enviar ao grupo: ${desc}. Verifique se o bot está adicionado e com permissão.`);
      }
      pendingAdmin.delete(ctx.from.id);
      await showAdminMenu(ctx);
      return;
    }
    if (a.step === 'refund_input') {
      let resolvedId: number | undefined;
      const fwd = (ctx.message as any)?.forward_from;
      if (fwd && typeof fwd.id === 'number') {
        resolvedId = Number(fwd.id);
      }
      if (!resolvedId && Array.isArray((ctx.message as any)?.entities)) {
        const mention = (ctx.message as any).entities.find((e: any) => e.type === 'mention');
        if (mention) {
          const username = text.slice(mention.offset, mention.offset + mention.length).replace(/^@/, '').trim();
          const u = store.getUserByQuery(username);
          if (u) resolvedId = u.telegram_id;
        }
      }
      if (!resolvedId) {
        const replyFrom = (ctx.message as any)?.reply_to_message?.from;
        if (replyFrom && typeof replyFrom.id === 'number') {
          resolvedId = Number(replyFrom.id);
        }
      }
      if (!resolvedId) {
        const m1 = text.match(/@([\w_]+)/);
        const m2 = text.match(/t\.me\/([\w_]+)/);
        const handle = (m1 && m1[1]) || (m2 && m2[1]);
        if (handle) {
          const u = store.getUserByQuery(handle);
          if (u) resolvedId = u.telegram_id;
        }
      }
      const parts = text.split(/\s+/).filter(Boolean);
      const nums = parts.map(p => Number(p)).filter(n => !Number.isNaN(n));
      let value: number | undefined;
      if (resolvedId === undefined) {
        if (nums.length >= 2) {
          resolvedId = nums[0];
          value = nums[1];
        } else if (nums.length === 1) {
          value = nums[0];
        }
      } else {
        if (nums.length >= 1) {
          value = nums[nums.length - 1];
        }
      }
      if (resolvedId === undefined || value === undefined || value <= 0) {
        await ctx.reply('Uso: <@username|ID> <valor> — ou encaminhe uma mensagem do usuário e informe o valor.');
        return;
      }
      const u = store.getOrCreateUser(resolvedId, String(resolvedId));
      store.addSaldo(u.id, value);
      await ctx.reply(`Reembolso creditado: R$${value}. Saldo atual: R$${u.saldo}.`);
      try {
        if (resolvedId !== ctx.from.id) {
          await ctx.telegram.sendMessage(resolvedId, `Reembolso creditado: R$${value}. Saldo atual: R$${u.saldo}.`);
        }
      } catch (sendError: any) {
        await ctx.reply(`Reembolso creditado, mas falha ao notificar o usuário: ${sendError.message}`);
      }
      pendingAdmin.delete(ctx.from.id);
      await showAdminMenu(ctx);
      return;
    }
    // Fluxo de edição de tutorial
    if (a.step === 'edit_tutorial_field') {
      const { tutorialId, field, type, userId } = a.data;
      const value = ctx.message?.text?.trim() ?? '';

      if (type === 'aff_percent') {
        const p = Number(value);
        if (Number.isNaN(p) || p < 0 || p > 100) { await ctx.reply('Porcentagem inválida.'); return; }
        const u = store.getUserById(userId);
        if (!u) { await ctx.reply('Afiliado não encontrado.'); return; }
        store.setAffiliatePercent(u.id, p);
        await ctx.reply(`Porcentagem atualizada para ${p}%.`);
        pendingAdmin.delete(ctx.from.id);
        await showAdminMenu(ctx);
        return;
      }

      const t = store.getTutorialById(tutorialId);
      if (!t) {
        await ctx.reply('CC FULL não encontrado.');
        pendingAdmin.delete(ctx.from.id);
        await showAdminMenu(ctx);
        return;
      }
    
      try {
        if (field === 'price') {
          const price = Number(value);
          if (Number.isNaN(price) || price <= 0) {
            await ctx.reply('Preço inválido. Informe um número maior que zero.');
            return;
          }
          store.updateTutorial(tutorialId, { price });
        } else if (field === 'title') {
          if (!value) {
            await ctx.reply('Título não pode ser vazio.');
            return;
          }
          store.updateTutorial(tutorialId, { title: value });
        } else if (field === 'description') {
          store.updateTutorial(tutorialId, { description: value });
        } else if (field === 'content') {
          store.updateTutorial(tutorialId, { content: value });
        }
    
        await ctx.reply(`CC FULL "${t.title}" atualizado com sucesso (${field}).`);
      } catch (err: any) {
        await ctx.reply(`Falha ao atualizar: ${err?.message || 'erro desconhecido'}`);
      }
    
      pendingAdmin.delete(ctx.from.id);
      await showAdminMenu(ctx);
      return;
    }
  }

  // Fluxos pendentes do usuário (add_balance / support)
  const state = pendingText.get(ctx.from.id);
  if (!state) return next();

  if (state.type === 'add_balance') {
    const value = Number(text);
    if (Number.isNaN(value) || value < 10) {
      await ctx.reply('Valor inválido. O mínimo para adicionar saldo é R$10.');
      return;
    }
    const user = store.getOrCreateUser(ctx.from.id, ctx.from.first_name || ctx.from.username || 'Usuário', ctx.from.username);
  const external_id = `add_balance_${user.id}_${Date.now()}`;
  const short_id = (await import('crypto')).default.createHash('sha256').update(external_id).digest('hex').slice(0, 12);
  let charge: any;
  try {
    charge = await (await import('./pix/provider')).pixProvider.createCharge({
        external_id,
        amount: value,
        description: `Recarga Saldo`,
        metadata: { userId: user.id, username: user.username, telegramName: user.name }
      });
  } catch (err: any) {
    const raw = err?.response?.data?.message;
    let msg = 'Falha ao criar cobrança PIX.';
    if (typeof raw === 'string' && raw.includes('below the minimum allowed')) {
      msg = 'Valor abaixo do mínimo permitido pelo provedor. Tente R$10 ou mais.';
    }
    await ctx.reply(msg);
    pendingText.delete(ctx.from.id);
    return;
  }
    store.savePixPayment({
      external_id,
      short_id,
      txid: charge.txid,
      amount: charge.amount,
      status: 'pending',
      provider_response: { ...charge, pix: { qrcode: charge.qrcode || charge.copy_paste || charge.pix?.qrcode } },
      pix_qrcode: charge.qrcode || charge.copy_paste || charge.pix?.qrcode
    });

    {
      const qrcode = charge.qrcode || charge.copy_paste || charge.pix?.qrcode || (charge as any)?.raw?.qrcode || (charge as any)?.raw?.qr_code || (charge as any)?.raw?.qrCode || (charge as any)?.raw?.code || '';
      const secureUrl = (charge as any)?.raw?.secureUrl || (charge as any)?.raw?.secure_url || undefined;
      const text = `Foi gerado seu PIX copia e cola:\n` +
        (qrcode ? `${qrcode}\n` : '') +
        `Clique sobre o PIX copia e cola para copiar e fazer o pagamento.\nEsse código expira em 10 minutos.`;
    const keyboard = secureUrl
      ? Markup.inlineKeyboard([[
          Markup.button.url('Abrir página de pagamento', secureUrl),
          Markup.button.callback('Copiar código', `copy_qr_${short_id}`),
          Markup.button.callback('Já paguei', `check_paid_${short_id}`)
        ]])
      : Markup.inlineKeyboard([[
          Markup.button.callback('Copiar código', `copy_qr_${short_id}`),
          Markup.button.callback('Já paguei', `check_paid_${short_id}`)
        ]]);
      try {
        if (qrcode) {
          const QR = (await import('qrcode')).default;
          const buf = await QR.toBuffer(qrcode, { type: 'png', margin: 1 });
          await ctx.replyWithPhoto({ source: buf }, { caption: text, reply_markup: keyboard.reply_markup });
        } else {
          await ctx.reply(text, keyboard);
        }
      } catch (_) {
        await ctx.reply(text, keyboard);
      }

      const secureId = (charge as any)?.raw?.secureId;
    setTimeout(async () => {
      try {
        const provider = (await import('./pix/provider')).pixProvider;
        const list = await provider.listTransactions();
        const match = Array.isArray(list) ? list.find((t: any) => t.secureId === secureId) : undefined;
        if (match && String(match.paymentMethod).toLowerCase() === 'pix') {
          if (String(match.status).toLowerCase() === 'paid') {
            const userIdStr = external_id.split('_')[2];
            const user = store.getUserById(userIdStr);
            if (user) {
              const pmt = store.getPixPaymentByShortId(short_id);
              if (pmt && pmt.status === 'paid') {
                return;
              }
              if (pmt) {
                pmt.status = 'paid';
                pmt.paid_at = new Date();
                pmt.provider_response = match;
                store.savePixPayment(pmt);
              }
              const valueCredits = Number(match.amount) / 100;
              store.addSaldo(user.id, valueCredits);
              if (user.referred_by) {
                const aff = store.getUserById(user.referred_by);
                const percent = aff?.affiliate_percent ?? 5;
                const commission = valueCredits * (percent / 100);
                if (aff && commission > 0) {
                  store.addAffiliateCommission(aff.id, user.id, commission, percent);
                }
              }
              await ctx.reply(`Seu pix foi creditado com sucesso. Saldo atual: R$${user.saldo.toFixed(2)}.`);
            }
          } else {
            const statusText = `Status da transação:\n` +
              `ID: ${match.id}\n` +
              `Valor: R$${(Number(match.amount)/100).toFixed(2)}\n` +
              `Método: ${match.paymentMethod}\n` +
              `Status: ${match.status}`;
            await ctx.reply(statusText);
          }
        }
      } catch (_) {}
    }, 60000);
  }

    pendingText.delete(ctx.from.id);
    return;
  }

  if (state.type === 'support') {
    const msg = text;
    const user = store.getOrCreateUser(ctx.from.id, ctx.from.first_name || ctx.from.username || 'Usuário', ctx.from.username);
    for (const adminId of config.adminUserIds) {
      await ctx.telegram.sendMessage(Number(adminId), `Suporte: de ${user.name} (${user.telegram_id})\n${msg}`);
    }
    await ctx.reply('Mensagem enviada ao suporte. Em breve responderemos.');
    pendingText.delete(ctx.from.id);
    return;
  }
  if (state.type === 'affiliate_pix') {
    const pixKey = text.trim();
    const u = store.getOrCreateUser(ctx.from.id, ctx.from.first_name || ctx.from.username || 'Usuário', ctx.from.username);
    store.setAffiliatePix(u.id, pixKey);
    await ctx.reply('Chave PIX cadastrada para afiliado.');
    pendingText.delete(ctx.from.id);
    return;
  }

  if (state.type === 'search_bin') {
    const raw = text.replace(/\D/g, '');
    if (raw.length !== 6) {
      await ctx.reply('BIN inválido. Informe 6 dígitos.');
      return;
    }
    const bin = raw;
    const matches = store.listTutorials().filter(t => {
      const m = t.title.match(/BIN:\s*(\d{6})/i);
      return !!m && m[1] === bin;
    });
    if (matches.length === 0) {
      await ctx.reply(`Nenhum CC encontrado para BIN ${bin}.`);
    } else {
      const lines = matches.map(t => {
        const hasPrice = /\bR\$?\s?\d+(?:[.,]\d+)?\b/i.test(t.title);
        return `${t.id} — ${t.title}${hasPrice ? '' : ` — R${t.price}`}`;
      });
      await ctx.reply(lines.join('\n'));
    }
    pendingText.delete(ctx.from.id);
    return;
  }

  if (state.type === 'search_bandeira') {
    const brand = text.trim().toUpperCase();
    if (!brand) {
      await ctx.reply('Bandeira inválida.');
      return;
    }
    const matches = store.listTutorials().filter(t => {
      const m = t.title.match(/BANDEIRA:\s*([^|]+)/i);
      const found = m ? m[1].trim().toUpperCase() : '';
      return !!found && found === brand;
    });
    if (matches.length === 0) {
      await ctx.reply(`Nenhum CC encontrado para bandeira ${brand}.`);
    } else {
      const lines = matches.map(t => {
        const hasPrice = /\bR\$?\s?\d+(?:[.,]\d+)?\b/i.test(t.title);
        return `${t.id} — ${t.title}${hasPrice ? '' : ` — R${t.price}`}`;
      });
      await ctx.reply(lines.join('\n'));
    }
    pendingText.delete(ctx.from.id);
    return;
  }

  if (state.type === 'search_banco') {
    const bank = text.trim().toUpperCase();
    if (!bank) {
      await ctx.reply('Banco inválido.');
      return;
    }
    const matches = store.listTutorials().filter(t => {
      const m = t.title.match(/BANCO:\s*([^|]+)/i);
      const found = m ? m[1].trim().toUpperCase() : '';
      return !!found && found.includes(bank);
    });
    if (matches.length === 0) {
      await ctx.reply(`Nenhum CC encontrado para banco ${bank}.`);
    } else {
      const lines = matches.map(t => {
        const hasPrice = /\bR\$?\s?\d+(?:[.,]\d+)?\b/i.test(t.title);
        return `${t.id} — ${t.title}${hasPrice ? '' : ` — R${t.price}`}`;
      });
      await ctx.reply(lines.join('\n'));
    }
    pendingText.delete(ctx.from.id);
    return;
  }

  if (state.type === 'search_lvl') {
    const lvl = text.trim().toUpperCase();
    if (!lvl) {
      await ctx.reply('Nível inválido.');
      return;
    }
    const matches = store.listTutorials().filter(t => {
      const m = t.title.match(/LVL:\s*([^|]+)/i);
      const found = m ? m[1].trim().toUpperCase() : '';
      return !!found && found === lvl;
    });
    if (matches.length === 0) {
      await ctx.reply(`Nenhum CC encontrado para nível ${lvl}.`);
    } else {
      const lines = matches.map(t => {
        const hasPrice = /\bR\$?\s?\d+(?:[.,]\d+)?\b/i.test(t.title);
        return `${t.id} — ${t.title}${hasPrice ? '' : ` — R${t.price}`}`;
      });
      await ctx.reply(lines.join('\n'));
    }
    pendingText.delete(ctx.from.id);
    return;
  }

  return next(); // segurança extra
});

bot.command('list_tutorials', async (ctx) => {
  if (!ensureAdmin(ctx)) return;
  const list = store.listTutorials().map(t => {
    const hasPrice = /\bR\$?\s?\d+(?:[.,]\d+)?\b/i.test(t.title);
    return `${t.id} — ${t.title}${hasPrice ? '' : ` — R${t.price}`}`;
  }).join('\n');
  await ctx.reply(list || 'Nenhum CC FULL.');
});

bot.command('refund', async (ctx) => {
  if (!ensureAdmin(ctx)) return;
  await ctx.reply('Refund não implementado (depende do provedor PIX).');
});

bot.command('broadcast', async (ctx) => {
  if (!ensureAdmin(ctx)) return;
  const msg = ctx.message.text.replace('/broadcast', '').trim();
  if (!msg) return ctx.reply('Informe a mensagem.');

  const chatId = Number(config.groupChatId);
  if (!chatId || Number.isNaN(chatId)) {
    await ctx.reply('GROUP_CHAT_ID inválido ou não configurado no .env.');
    return;
  }

  try {
    await ctx.telegram.sendMessage(chatId, `[Broadcast]: ${msg}`);
    await ctx.reply('Mensagem enviada ao grupo.');
  } catch (err: any) {
    const desc = err?.response?.description || err?.message || 'Erro desconhecido';
    await ctx.reply(`Falha ao enviar ao grupo: ${desc}. Verifique se o bot está adicionado e com permissão.`);
  }
});  bot.catch(async (err: any, ctx: any) => {
    console.error('Unhandled error while processing', ctx.update, err);
    try {
      await ctx.reply('Ocorreu um erro ao processar sua ação. Tente novamente.');
    } catch (_) {}
  });

// Declaração utilitária para responder callback queries com segurança
async function safelyAnswerCb(ctx: any) {
  try {
    await ctx.answerCbQuery();
  } catch (_) {
    // Ignora erros de "query is too old" ou "invalid query id"
  }
}

// Handler: abrir opções de edição do tutorial (apenas mostra botões de campos)
bot.action(/admin_edit_(.+)/, async (ctx) => {
  if (!ensureAdmin(ctx)) return;
  await safelyAnswerCb(ctx);

  const tutorialId = ctx.match[1];
  const t = store.getTutorialById(tutorialId);
  if (!t) {
    await ctx.reply('CC FULL não encontrado.');
    return;
  }

  await ctx.reply(
    `Editar "${t.title}" — selecione o campo:`,
    Markup.inlineKeyboard([
      [
        Markup.button.callback('Título', `ae_t:${tutorialId}`),
        Markup.button.callback('Descrição', `ae_d:${tutorialId}`)
      ],
      [
        Markup.button.callback('Preço', `ae_p:${tutorialId}`),
        Markup.button.callback('Conteúdo', `ae_c:${tutorialId}`)
      ]
    ])
  );
});

// Handler: seleciona o campo e inicia o passo de edição (formato curto)
bot.action(/^ae_(t|d|p|c):(.+)$/, async (ctx) => {
  if (!ensureAdmin(ctx)) return;
  await safelyAnswerCb(ctx);

  const code = ctx.match[1];             // t | d | p | c
  const tutorialId = ctx.match[2];

  const field = code === 't' ? 'title'
              : code === 'd' ? 'description'
              : code === 'p' ? 'price'
              : 'content';

  const t = store.getTutorialById(tutorialId);
  if (!t) {
    await ctx.reply('CC FULL não encontrado.');
    return;
  }

  pendingAdmin.set(ctx.from.id, { step: 'edit_tutorial_field', data: { tutorialId, field } });
  await ctx.reply(`Envie o novo valor para ${field.toUpperCase()}:`);
  await safelyAnswerCb(ctx);
}); 

// Handler: remoção de tutorial via botão inline
bot.action(/admin_remove_(.+)/, async (ctx) => {
  if (!ensureAdmin(ctx)) return;
  await safelyAnswerCb(ctx);

  const tutorialId = ctx.match[1];
  const t = store.getTutorialById(tutorialId);
  if (!t) {
    await ctx.reply('CC FULL não encontrado.');
    return;
  }

  const ok = store.removeTutorial(tutorialId);
  await ctx.reply(ok ? `CC FULL removido: ${t.title}` : 'Falha ao remover CC FULL.');
  await showAdminMenu(ctx);
});
bot.use(async (ctx, next) => {
  const from = ctx.from;
  if (from) {
    store.getOrCreateUser(from.id, from.first_name || from.username || 'Usuário', from.username);
  }
  return next();
});
bot.action(/copy_qr_(.+)/, async (ctx) => {
  await safelyAnswerCb(ctx);
  try { await ctx.editMessageReplyMarkup(undefined); } catch (_) {}
  const shortId = ctx.match[1];
  const payment = store.getPixPaymentByShortId(shortId);
  const code = payment?.pix_qrcode || (payment?.provider_response?.pix?.qrcode) || (payment?.provider_response?.copy_paste) || '';
  if (!code) {
    await ctx.reply('Código não disponível. Tente criar novamente a cobrança.');
    return;
  }
  await ctx.reply(code);
});
bot.action(/check_paid_(.+)/, async (ctx) => {
  await safelyAnswerCb(ctx);
  try { await ctx.editMessageReplyMarkup(undefined); } catch (_) {}
  const shortId = ctx.match[1];
  const pmt = store.getPixPaymentByShortId(shortId);
  if (!pmt) {
    await ctx.reply('Cobrança não encontrada. Gere novamente.');
    return;
  }
  const secureId = (pmt.provider_response?.raw?.secureId) || (pmt.provider_response?.secureId);
  if (!secureId) {
    await ctx.reply('Cobrança sem identificador. Gere novamente.');
    return;
  }
  setTimeout(async () => {
    try {
      const provider = (await import('./pix/provider')).pixProvider;
      const list = await provider.listTransactions();
      const match = Array.isArray(list) ? list.find((t: any) => t.secureId === secureId) : undefined;
      if (match && String(match.paymentMethod).toLowerCase() === 'pix') {
        if (String(match.status).toLowerCase() === 'paid') {
          const parts = String(pmt.external_id).split('_');
          const userIdStr = parts[2];
          const user = store.getUserById(userIdStr);
          if (user) {
            if (pmt.status !== 'paid') {
              pmt.status = 'paid';
              pmt.paid_at = new Date();
              pmt.provider_response = match;
              store.savePixPayment(pmt);
              const valueCredits = Number(match.amount) / 100;
              store.addSaldo(user.id, valueCredits);
              if (user.referred_by) {
                const aff = store.getUserById(user.referred_by);
                const percent = aff?.affiliate_percent ?? 5;
                const commission = valueCredits * (percent / 100);
                if (aff && commission > 0) {
                  store.addAffiliateCommission(aff.id, user.id, commission, percent);
                }
              }
            }
            await ctx.reply(`Seu pix foi creditado com sucesso. Saldo atual: R$${user.saldo.toFixed(2)}.`);
            return;
          }
        } else {
          await ctx.reply(`Status atual: ${match.status}. Aguarde a confirmação.`);
          return;
        }
      }
      await ctx.reply('Transação não localizada. Tente novamente mais tarde.');
    } catch (e: any) {
      await ctx.reply('Falha ao consultar status. Tente novamente.');
    }
  }, 10000);
});
bot.action('admin_refund', async (ctx) => {
  await safelyAnswerCb(ctx);
  if (!ensureAdmin(ctx)) return;
  pendingAdmin.set(ctx.from.id, { step: 'refund_input' });
  await ctx.reply('Envie: <@username|ID> <valor> — ou encaminhe a mensagem do usuário e informe o valor.');
});
bot.action('admin_affiliates', async (ctx) => {
  await safelyAnswerCb(ctx);
  if (!ensureAdmin(ctx)) return;
  const list = store.listAffiliates();
  if (list.length === 0) {
    await ctx.reply('Nenhum afiliado cadastrado.');
    return;
  }
  for (const a of list) {
    const text = `Afiliado: ${a.id} — @${a.username || a.name}\n% Comissão: ${a.affiliate_percent ?? 0}\nSaldo: R$${(a.saldo).toFixed(2)}`;
    await ctx.reply(text, Markup.inlineKeyboard([
      [
        Markup.button.callback('Ver Comissões', `admin_aff_view_${a.id}`),
        Markup.button.callback('Mudar % Comissão', `admin_aff_percent_${a.id}`)
      ]
    ]));
  }
});
bot.action(/admin_aff_view_(.+)/, async (ctx) => {
  await safelyAnswerCb(ctx);
  if (!ensureAdmin(ctx)) return;
  const uid = ctx.match[1];
  const u = store.getUserById(uid);
  if (!u) { await ctx.reply('Afiliado não encontrado.'); return; }
  const items = u.affiliate_commissions || [];
  if (items.length === 0) { await ctx.reply('Sem comissões registradas.'); return; }
  const lines = items.slice(-10).map(it => {
    const r = store.getUserById(it.user_id);
    const who = r ? `@${r.username || r.name}` : it.user_id;
    return `${who} — R$${it.amount.toFixed(2)} — ${it.percent}% — ${new Date(it.timestamp).toLocaleString()}`;
  });
  await ctx.reply(lines.join('\n'));
});
bot.action(/admin_aff_percent_(.+)/, async (ctx) => {
  await safelyAnswerCb(ctx);
  if (!ensureAdmin(ctx)) return;
  const uid = ctx.match[1];
  pendingAdmin.set(ctx.from.id, { step: 'edit_tutorial_field', data: { type: 'aff_percent', userId: uid } });
  await ctx.reply('Envie a nova porcentagem de comissão (0 a 100).');
});
