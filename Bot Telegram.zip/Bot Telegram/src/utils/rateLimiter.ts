const counters = new Map<string, { count: number; windowStart: number }>();

export function canPerform(key: string, maxPerHour: number): boolean {
  const now = Date.now();
  const windowMs = 60 * 60 * 1000;
  const c = counters.get(key);
  if (!c || now - c.windowStart >= windowMs) {
    counters.set(key, { count: 1, windowStart: now });
    return true;
  }
  if (c.count < maxPerHour) {
    c.count += 1;
    return true;
  }
  return false;
}

const lastActions = new Map<string, number>();

export function notRecentlyPerformed(key: string, cooldownMs: number): boolean {
  const now = Date.now();
  const last = lastActions.get(key) || 0;
  if (now - last >= cooldownMs) {
    lastActions.set(key, now);
    return true;
  }
  return false;
}