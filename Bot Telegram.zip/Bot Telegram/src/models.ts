export type PaymentMethod = 'saldo' | 'pix';
export type PurchaseStatus = 'pending' | 'completed' | 'failed';

export interface User {
  id: string;
  telegram_id: number;
  name: string;
  username?: string;
  saldo: number;
  affiliate_code?: string;
  affiliate_pix?: string;
  affiliate_percent?: number;
  referred_by?: string;
  affiliate_commissions?: Array<{ user_id: string; amount: number; percent: number; timestamp: string }>;
  created_at: Date;
}

export interface Tutorial {
  id: string;
  title: string;
  price: number;
  description: string;
  content: string;
  thumbnail?: string;
  created_at: Date;
}

export interface Purchase {
  id: string;
  user_id: string;
  tutorial_id: string;
  price_paid: number;
  method: PaymentMethod;
  external_id?: string;
  txid?: string;
  status: PurchaseStatus;

  created_at: Date;
  paid_at?: Date;
}

export interface PixPayment {
  external_id: string;
  short_id?: string;
  txid?: string;
  amount: number;
  status: 'created' | 'pending' | 'paid' | 'confirmed' | 'failed';
  paid_at?: Date;
  provider_response?: any;
  pix_qrcode?: string;
}

export interface PixWebhookPayload {
  external_id: string;
  txid?: string;
  amount: number;
  status: 'paid' | 'confirmed' | 'failed';
  paid_at?: string;
}