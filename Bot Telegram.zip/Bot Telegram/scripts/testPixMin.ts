import 'dotenv/config';
import { pixProvider } from '../src/pix/provider';

async function main() {
  const results: Array<{ amount: number; ok: boolean; info: string }> = [];
  for (let amount = 6; amount <= 20; amount++) {
    const external_id = `min_test_${amount}_${Date.now()}`;
    try {
      const charge = await pixProvider.createCharge({
        external_id,
        amount,
        description: 'Teste Min PIX',
        metadata: { userId: 'min_test', username: 'min_test' }
      });
      const hasQr = !!(charge.qrcode || charge.copy_paste || charge.pix?.qrcode);
      results.push({ amount, ok: true, info: hasQr ? 'qrcode' : 'no-qrcode' });
      break;
    } catch (err: any) {
      const msg = err?.response?.data?.message || err?.message || String(err);
      results.push({ amount, ok: false, info: msg });
    }
    // Pequena pausa para evitar rate limiting
    await new Promise(r => setTimeout(r, 300));
  }
  const firstOk = results.find(r => r.ok);
  if (firstOk) {
    console.log(JSON.stringify({ minimumAccepted: firstOk.amount, trail: results }, null, 2));
  } else {
    console.log(JSON.stringify({ minimumAccepted: null, trail: results }, null, 2));
  }
}

main().catch(e => {
  console.error('Erro no teste:', e);
  process.exit(1);
});