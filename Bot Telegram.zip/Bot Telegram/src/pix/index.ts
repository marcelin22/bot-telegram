import { v4 as uuid } from 'uuid';
import crypto from 'crypto';
import { pixProvider } from './provider';
import { store } from '../store';
import { PixWebhookPayload } from '../models';

export async function createPixChargeForPurchase(userId: string, tutorialId: string) {
  const tutorial = store.getTutorialById(tutorialId);
  if (!tutorial) throw new Error('CC FULL não encontrado');
  const user = store.getUserById(userId);
  if (!user) throw new Error('Usuário não encontrado');

  const external_id = `purchase_${userId}_${Date.now()}`;
  const charge = await pixProvider.createCharge({
    external_id,
    amount: tutorial.price,
    description: `Compra CC FULL`,
    metadata: { userId, tutorialId, username: user.username, telegramName: user.name }
  });
  const short_id = crypto.createHash('sha256').update(external_id).digest('hex').slice(0, 12);

  const purchase = await store.createPurchase({
    userId,
    tutorialId,
    price: tutorial.price,
    method: 'pix',
    external_id
  });

  store.savePixPayment({
    external_id,
    short_id,
    txid: charge.txid,
    amount: charge.amount,
    status: 'pending',
    provider_response: { ...charge, pix: { qrcode: charge.qrcode || charge.copy_paste || charge.pix?.qrcode } },
    pix_qrcode: charge.qrcode || charge.copy_paste || charge.pix?.qrcode
  });

  return { charge, purchase };
}

export async function handlePixWebhook(payload: PixWebhookPayload) {
  // Fluxo de adicionar saldo via PIX
  if (payload.external_id.startsWith('add_balance_')) {
    const parts = payload.external_id.split('_'); // ['add','balance',userId,ts]
    const userId = parts[2];
    const user = store.getUserById(userId);
    if (!user) {
      console.error('Usuário não encontrado para crédito de saldo:', userId);
      return { ok: false, kind: 'add_balance', reason: 'user_not_found', userId };
    }
    if (payload.status === 'paid' || payload.status === 'confirmed') {
      store.addSaldo(userId, payload.amount);
      store.savePixPayment({
        external_id: payload.external_id,
        txid: payload.txid,
        amount: payload.amount,
        status: payload.status as any,
        paid_at: payload.paid_at ? new Date(payload.paid_at) : undefined,
        provider_response: payload
      });
      return { ok: true, kind: 'add_balance', userId, amount: payload.amount };
    } else {
      return { ok: false, kind: 'add_balance', userId, amount: payload.amount, reason: 'status_not_paid' };
    }
  }

  // Fluxo de compra (purchase) — como antes
  const purchase = store.findPurchaseByExternalId(payload.external_id);
  if (!purchase) {
    console.error('Webhook PIX sem purchase:', payload.external_id);
    return { ok: false, kind: 'purchase', reason: 'purchase_not_found' };
  }
  if (!(payload.status === 'paid' || payload.status === 'confirmed')) {
    console.warn('Webhook PIX status não pago:', payload.status);
    return { ok: false, kind: 'purchase', reason: 'status_not_paid' };
  }

  const tutorial = store.getTutorialById(purchase.tutorial_id);
  if (!tutorial) {
    console.error('CC FULL não encontrado para purchase:', purchase.id);
    return { ok: false, kind: 'purchase', reason: 'tutorial_not_found' };
  }

  await store.setPurchaseCompleted(
    purchase.id,
    payload.txid,
    payload.paid_at ? new Date(payload.paid_at) : undefined
  );
  store.savePixPayment({
    external_id: payload.external_id,
    txid: payload.txid,
    amount: payload.amount,
    status: payload.status as any,
    paid_at: payload.paid_at ? new Date(payload.paid_at) : undefined,
    provider_response: payload
  });

  return { ok: true, kind: 'purchase', purchase, content: tutorial.content };
}

export async function pollPixUntilConfirmed(external_id: string, timeoutMs = 30 * 60 * 1000, intervalMs = 5000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const status = await pixProvider.getPaymentStatus(external_id);
    if (status.status === 'paid' || status.status === 'confirmed') {
      const res = await handlePixWebhook({
        external_id,
        txid: status.txid,
        amount: status.amount,
        status: status.status,
        paid_at: status.paid_at
      });
      return res;
    }
    await new Promise(r => setTimeout(r, intervalMs));
  }
  return { ok: false, reason: 'timeout' };
}