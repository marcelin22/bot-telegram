import request from 'supertest';
import express from 'express';
import bodyParser from 'body-parser';
import { config } from '../src/config';
import { store } from '../src/store';
import { bot } from '../src/bot';

jest.mock('../src/bot', () => {
  const original = jest.requireActual('../src/bot');
  return {
    ...original,
    bot: {
      telegram: {
        sendMessage: jest.fn().mockResolvedValue(true)
      }
    }
  };
});

describe('PIX webhook flow', () => {
  const app = express();
  app.use(bodyParser.json({ type: '*/*' }));
  app.post('/webhook/pix', async (req, res) => {
    const secret = req.headers['x-webhook-secret'] || req.query.secret;
    if (secret !== config.pix.webhookSecret) {
      return res.status(403).json({ ok: false });
    }
    const payload = req.body as any;
    const { handlePixWebhook } = await import('../src/pix');
    const r = await handlePixWebhook(payload);
    if (r.ok) {
      const u = store.getUserById(r.purchase!.user_id)!;
      await (await import('../src/bot')).bot.telegram.sendMessage(u.telegram_id, `Pagamento confirmado ✅ — aqui está seu texto secreto: ${r.content}`);
    }
    res.json(r);
  });

  beforeAll(() => {
    process.env.PIX_PROVIDER_WEBHOOK_SECRET = 'test-secret';
    process.env.DOWNLOAD_LINK_TTL_HOURS = '48';
    // seed: user + tutorial + purchase pending
    const user = store.getOrCreateUser(9999, 'Tester');
    store.addTutorial({ title: 'Guia Avançado', price: 20, description: 'Desc teste', content: 'Texto secreto de teste' });
    const tutorial = store.listTutorials()[0];
    store.createPurchase({
      userId: user.id, tutorialId: tutorial.id, price: tutorial.price, method: 'pix', external_id: 'purchase_' + user.id + '_seed'
    });
  });

  it('reconciles purchase on paid webhook', async () => {
    const resp = await request(app)
      .post('/webhook/pix')
      .set('x-webhook-secret', 'test-secret')
      .send({
        external_id: 'purchase_' + store.getOrCreateUser(9999, 'Tester').id + '_seed',
        txid: 'abc123',
        amount: 20,
        status: 'paid',
        paid_at: new Date().toISOString()
      });
    expect(resp.status).toBe(200);
    expect(resp.body.ok).toBe(true);
    const purchase = store.findPurchaseByExternalId('purchase_' + store.getOrCreateUser(9999, 'Tester').id + '_seed')!;
    expect(purchase.status).toBe('completed');

    const mockedSend = (await import('../src/bot')).bot.telegram.sendMessage as any;
    expect(mockedSend).toHaveBeenCalled();
  });
});