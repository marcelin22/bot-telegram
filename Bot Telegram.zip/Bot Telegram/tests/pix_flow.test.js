"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const supertest_1 = __importDefault(require("supertest"));
const express_1 = __importDefault(require("express"));
const body_parser_1 = __importDefault(require("body-parser"));
const config_1 = require("../src/config");
const store_1 = require("../src/store");
jest.mock('../src/bot', () => {
    const original = jest.requireActual('../src/bot');
    return {
        ...original,
        bot: {
            telegram: {
                sendMessage: jest.fn().mockResolvedValue(true)
            }
        }
    };
});
describe('PIX webhook flow', () => {
    const app = (0, express_1.default)();
    app.use(body_parser_1.default.json({ type: '*/*' }));
    app.post('/webhook/pix', async (req, res) => {
        const secret = req.headers['x-webhook-secret'] || req.query.secret;
        if (secret !== config_1.config.pix.webhookSecret) {
            return res.status(403).json({ ok: false });
        }
        const payload = req.body;
        const { handlePixWebhook } = await Promise.resolve().then(() => __importStar(require('../src/pix')));
        const r = await handlePixWebhook(payload);
        if (r.ok) {
            const u = store_1.store.getUserById(r.purchase.user_id);
            await (await Promise.resolve().then(() => __importStar(require('../src/bot')))).bot.telegram.sendMessage(u.telegram_id, `Pagamento confirmado ✅ — aqui está seu link (válido 48h): ${r.link}`);
        }
        res.json(r);
    });
    beforeAll(() => {
        process.env.PIX_PROVIDER_WEBHOOK_SECRET = 'test-secret';
        process.env.DOWNLOAD_LINK_TTL_HOURS = '48';
        // seed: user + tutorial + purchase pending
        const user = store_1.store.getOrCreateUser(9999, 'Tester');
        store_1.store.addTutorial({ title: 'Guia Avançado', price: 20, description: 'Desc teste', link: 'https://example.com/arquivo.pdf' });
        const tutorial = store_1.store.listTutorials()[0];
        store_1.store.createPurchase({
            userId: user.id, tutorialId: tutorial.id, price: tutorial.price, method: 'pix', external_id: 'purchase_' + user.id + '_seed'
        });
    });
    it('reconciles purchase on paid webhook', async () => {
        const resp = await (0, supertest_1.default)(app)
            .post('/webhook/pix')
            .set('x-webhook-secret', 'test-secret')
            .send({
            external_id: 'purchase_' + store_1.store.getOrCreateUser(9999, 'Tester').id + '_seed',
            txid: 'abc123',
            amount: 20,
            status: 'paid',
            paid_at: new Date().toISOString()
        });
        expect(resp.status).toBe(200);
        expect(resp.body.ok).toBe(true);
        const purchase = store_1.store.findPurchaseByExternalId('purchase_' + store_1.store.getOrCreateUser(9999, 'Tester').id + '_seed');
        expect(purchase.status).toBe('completed');
        expect(purchase.download_link).toBe('https://example.com/arquivo.pdf');
        const mockedSend = (await Promise.resolve().then(() => __importStar(require('../src/bot')))).bot.telegram.sendMessage;
        expect(mockedSend).toHaveBeenCalled();
    });
});
