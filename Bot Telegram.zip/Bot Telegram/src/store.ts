import fs from 'fs/promises';
import path from 'path';
import { v4 as uuid } from 'uuid';
import { User, Tutorial, Purchase, PixPayment } from './models';

const DATA_DIR = path.join(__dirname, '..', 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const TUTORIALS_FILE = path.join(DATA_DIR, 'tutorials.json');
const PURCHASES_FILE = path.join(DATA_DIR, 'purchases.json');
const PIX_PAYMENTS_FILE = path.join(DATA_DIR, 'pix_payments.json');

async function ensureDataDir() {
  try {
    await fs.mkdir(DATA_DIR, { recursive: true });
  } catch (err) {}
}

class PersistentStore {
  users = new Map<string, User>();
  usersByTelegramId = new Map<number, string>();
  usersByUsername = new Map<string, string>();
  tutorials = new Map<string, Tutorial>();
  purchases = new Map<string, Purchase>();
  pixPayments = new Map<string, PixPayment>();
  private purchaseSaveQueue: Promise<void> = Promise.resolve();
  private usedNumericTutorialIds = new Set<number>();

  constructor() {
    this.loadAll();
  }

  private async loadAll() {
    await ensureDataDir();
    await this.loadUsers();
    await this.loadTutorials();
    await this.loadPurchases();
    await this.loadPixPayments();
    await this.migrateTutorialIdsIfNeeded();
  }

  private async saveAll() {
    await this.saveUsers();
    await this.saveTutorials();
    await this.savePurchases();
    await this.savePixPayments();
  }

  private async loadUsers() {
    try {
      const data = await fs.readFile(USERS_FILE, 'utf8');
      const usersArray: User[] = JSON.parse(data);
      usersArray.forEach(user => {
        this.users.set(user.id, user);
        this.usersByTelegramId.set(user.telegram_id, user.id);
        if (user.username) this.usersByUsername.set(user.username.toLowerCase(), user.id);
      });
    } catch (err) {
      if ((err as any).code !== 'ENOENT') console.error('Erro ao carregar users:', err);
    }
  }

  private async saveUsers() {
    const usersArray = Array.from(this.users.values());
    await fs.writeFile(USERS_FILE, JSON.stringify(usersArray, null, 2));
  }

  private async loadTutorials() {
    try {
      const data = await fs.readFile(TUTORIALS_FILE, 'utf8');
      const tutorialsArray: Tutorial[] = JSON.parse(data);
      tutorialsArray.forEach(tut => {
        this.tutorials.set(tut.id, tut);
        const n = Number(tut.id);
        if (!Number.isNaN(n) && n > 0 && n <= 99999 && /^\d{1,5}$/.test(tut.id)) {
          this.usedNumericTutorialIds.add(n);
        }
      });
    } catch (err) {
      if ((err as any).code !== 'ENOENT') console.error('Erro ao carregar tutorials:', err);
    }
  }

  private async saveTutorials() {
    const tutorialsArray = Array.from(this.tutorials.values());
    await fs.writeFile(TUTORIALS_FILE, JSON.stringify(tutorialsArray, null, 2));
  }

  private async loadPurchases() {
    try {
      const data = await fs.readFile(PURCHASES_FILE, 'utf8');
      const purchasesArray: Purchase[] = JSON.parse(data);
      purchasesArray.forEach(p => this.purchases.set(p.id, p));
    } catch (err: any) {
      if (err.code === 'ENOENT') {
        // arquivo não existe ainda; ok
        return;
      }
      console.error('Erro ao carregar purchases:', err);
      // Tentar recuperar: backup e resetar arquivo
      try {
        const backup = PURCHASES_FILE.replace(/\.json$/, `.bak.${Date.now()}.json`);
        await fs.copyFile(PURCHASES_FILE, backup);
        await fs.writeFile(PURCHASES_FILE, '[]');
        console.warn('purchases.json corrompido: backup criado e arquivo resetado para [].');
      } catch (recErr) {
        console.error('Falha ao recuperar purchases.json:', recErr);
      }
    }
  }

  private async savePurchases() {
    const performSave = async () => {
      const purchasesArray = Array.from(this.purchases.values());
      // escrita atômica com tmp único por chamada e fila para evitar corrida
      const tmp = PURCHASES_FILE + `.tmp.${Date.now()}`;
      await fs.writeFile(tmp, JSON.stringify(purchasesArray, null, 2));
      await fs.rename(tmp, PURCHASES_FILE);
    };
    this.purchaseSaveQueue = this.purchaseSaveQueue
      .then(performSave)
      .catch((err) => {
        console.error('Erro ao salvar purchases:', err);
      });
    return this.purchaseSaveQueue;
  }

  private async loadPixPayments() {
    try {
      const data = await fs.readFile(PIX_PAYMENTS_FILE, 'utf8');
      const pixPaymentsArray: PixPayment[] = JSON.parse(data);
      pixPaymentsArray.forEach(payment => this.pixPayments.set(payment.external_id, payment));
    } catch (err) {
      if ((err as any).code !== 'ENOENT') console.error('Erro ao carregar pixPayments:', err);
    }
  }

  private async savePixPayments() {
    const pixPaymentsArray = Array.from(this.pixPayments.values());
    await fs.writeFile(PIX_PAYMENTS_FILE, JSON.stringify(pixPaymentsArray, null, 2));
  }

  getOrCreateUser(telegram_id: number, name: string, username?: string): User {
    const existingId = this.usersByTelegramId.get(telegram_id);
    if (existingId) {
      const u = this.users.get(existingId)!;
      let changed = false;
      if (name && u.name !== name) { u.name = name; changed = true; }
      if (username && u.username !== username) {
        if (u.username) this.usersByUsername.delete(u.username.toLowerCase());
        u.username = username;
        this.usersByUsername.set(username.toLowerCase(), u.id);
        changed = true;
      }
      if (changed) this.saveUsers();
      return u;
    }
    const id = uuid();
    const user: User = { id, telegram_id, name, username, saldo: 0, created_at: new Date(), affiliate_percent: 5 };
    this.users.set(id, user);
    this.usersByTelegramId.set(telegram_id, id);
    if (username) this.usersByUsername.set(username.toLowerCase(), id);
    this.saveUsers();
    return user;
  }

  addSaldo(userId: string, value: number): void {
    const u = this.users.get(userId);
    if (!u) throw new Error('Usuário não encontrado');
    u.saldo += value;
    this.saveUsers();
  }

  ensureAffiliate(userId: string): User {
    const u = this.users.get(userId);
    if (!u) throw new Error('Usuário não encontrado');
    if (!u.affiliate_code) {
      const code = Math.random().toString(36).slice(2, 10);
      u.affiliate_code = code;
      if (u.affiliate_percent === undefined) u.affiliate_percent = 5;
      this.saveUsers();
    }
    return u;
  }

  setAffiliatePix(userId: string, pixKey: string): void {
    const u = this.users.get(userId);
    if (!u) throw new Error('Usuário não encontrado');
    u.affiliate_pix = pixKey;
    this.saveUsers();
  }

  findAffiliateByCode(code: string): User | undefined {
    for (const u of this.users.values()) {
      if (u.affiliate_code === code) return u;
    }
    return undefined;
  }

  setUserReferredBy(userId: string, affiliateId: string): void {
    const u = this.users.get(userId);
    if (!u) throw new Error('Usuário não encontrado');
    if (!u.referred_by) {
      u.referred_by = affiliateId;
      this.saveUsers();
    }
  }

  addAffiliateCommission(affiliateId: string, fromUserId: string, amount: number, percent: number): void {
    const aff = this.users.get(affiliateId);
    if (!aff) return;
    if (!Array.isArray(aff.affiliate_commissions)) aff.affiliate_commissions = [];
    aff.affiliate_commissions.push({ user_id: fromUserId, amount, percent, timestamp: new Date().toISOString() });
    aff.saldo += amount;
    this.saveUsers();
  }

  listAffiliates(): User[] {
    return Array.from(this.users.values()).filter(u => !!u.affiliate_code);
  }

  setAffiliatePercent(userId: string, percent: number): void {
    const u = this.users.get(userId);
    if (!u) throw new Error('Usuário não encontrado');
    u.affiliate_percent = percent;
    this.saveUsers();
  }

  addTutorial(input: Omit<Tutorial, 'id' | 'created_at'>): Tutorial {
    const id = this.allocateTutorialNumericId();
    const tut: Tutorial = { id: String(id), created_at: new Date(), ...input };
    this.tutorials.set(String(id), tut);
    this.saveTutorials();
    return tut;
  }

  listTutorials(): Tutorial[] {
    return Array.from(this.tutorials.values());
  }

  updateTutorial(tutorialId: string, changes: Partial<Pick<Tutorial, 'title' | 'description' | 'price' | 'content' | 'thumbnail'>>): Tutorial {
    const tut = this.tutorials.get(tutorialId);
    if (!tut) throw new Error('CC FULL não encontrado');
    if (changes.title !== undefined) tut.title = changes.title;
    if (changes.description !== undefined) tut.description = changes.description;
    if (changes.price !== undefined) tut.price = changes.price;
    if (changes.content !== undefined) tut.content = changes.content;
    if (changes.thumbnail !== undefined) tut.thumbnail = changes.thumbnail;
    this.saveTutorials();
    return tut;
  }

  removeTutorial(tutorialId: string): boolean {
    const ok = this.tutorials.delete(tutorialId);
    if (ok) this.saveTutorials();
    return ok;
  }

  async createPurchase(params: {
    userId: string;
    tutorialId: string;
    price: number;
    method: 'saldo' | 'pix';
    external_id?: string;
  }): Promise<Purchase> {
    const id = uuid();
    const purchase: Purchase = {
      id,
      user_id: params.userId,
      tutorial_id: params.tutorialId,
      price_paid: params.price,
      method: params.method,
      external_id: params.external_id,
      status: params.method === 'saldo' ? 'completed' : 'pending',
      created_at: new Date()
    };
    this.purchases.set(id, purchase);
    await this.savePurchases();
    return purchase;
  }

  async setPurchaseCompleted(purchaseId: string, txid: string | undefined, paidAt: Date | undefined) {
    const p = this.purchases.get(purchaseId);
    if (!p) throw new Error('Compra não encontrada');
    p.txid = txid;
    p.status = 'completed';
    p.paid_at = paidAt;

    await this.savePurchases();
  }

  findPurchaseByExternalId(externalId: string): Purchase | undefined {
    return Array.from(this.purchases.values()).find(p => p.external_id === externalId);
  }

  getPixPaymentByExternalId(externalId: string): PixPayment | undefined {
    return this.pixPayments.get(externalId);
  }

  listPurchasesByUser(userId: string): Purchase[] {
    return Array.from(this.purchases.values()).filter(p => p.user_id === userId);
  }

  hasUserPurchased(userId: string, tutorialId: string): boolean {
    for (const p of this.purchases.values()) {
      if (p.user_id === userId && p.tutorial_id === tutorialId && p.status === 'completed') return true;
    }
    return false;
  }

  listAvailableTutorialsForUser(userId: string): Tutorial[] {
    const all = Array.from(this.tutorials.values());
    return all.filter(t => !this.hasUserPurchased(userId, t.id));
  }

  hasGloballyPurchased(tutorialId: string): boolean {
    for (const p of this.purchases.values()) {
      if (p.tutorial_id === tutorialId && p.status === 'completed') return true;
    }
    return false;
  }

  listAvailableTutorials(): Tutorial[] {
    const all = Array.from(this.tutorials.values());
    return all.filter(t => !this.hasGloballyPurchased(t.id));
  }

  savePixPayment(payment: PixPayment): void {
    this.pixPayments.set(payment.external_id, payment);
    this.savePixPayments();
  }

  getPixPaymentByShortId(shortId: string): PixPayment | undefined {
    for (const p of this.pixPayments.values()) {
      if (p.short_id === shortId) return p;
    }
    return undefined;
  }

  getUserById(userId: string): User | undefined {
    return this.users.get(userId);
  }

  getUserByName(name: string): User | undefined {
    const lower = name.trim().toLowerCase();
    for (const u of this.users.values()) {
      const n = (u.name || '').trim().toLowerCase();
      if (n === lower) return u;
    }
    return undefined;
  }

  getUserByQuery(query: string): User | undefined {
    const q = query.trim().toLowerCase().replace(/^@/, '');
    for (const u of this.users.values()) {
      const name = (u.name || '').trim().toLowerCase();
      const nameNoAt = name.replace(/^@/, '');
      if (name === q || nameNoAt === q) return u;
      if (name.includes(q) || nameNoAt.includes(q)) return u;
      const uname = (u.username || '').trim().toLowerCase();
      if (uname === q) return u;
    }
    const idFromUsername = this.usersByUsername.get(q);
    if (idFromUsername) return this.users.get(idFromUsername);
    return undefined;
  }

  getTutorialById(tutorialId: string): Tutorial | undefined {
    return this.tutorials.get(tutorialId);
  }

  private allocateTutorialNumericId(): number {
    // Prefer próximo número disponível baseado no maior já usado
    let start = 1;
    if (this.usedNumericTutorialIds.size > 0) {
      start = Math.max(...Array.from(this.usedNumericTutorialIds.values())) + 1;
    }
    for (let i = 0; i < 100000; i++) {
      const candidate = ((start + i - 1) % 99999) + 1;
      if (!this.usedNumericTutorialIds.has(candidate) && !this.tutorials.has(String(candidate))) {
        this.usedNumericTutorialIds.add(candidate);
        return candidate;
      }
    }
    // fallback raro
    const fallback = Math.floor(Math.random() * 99999) + 1;
    this.usedNumericTutorialIds.add(fallback);
    return fallback;
  }

  private async migrateTutorialIdsIfNeeded() {
    const mapping = new Map<string, string>();
    for (const [id, tut] of Array.from(this.tutorials.entries())) {
      if (!/^\d{1,5}$/.test(id)) {
        const newIdNum = this.allocateTutorialNumericId();
        const newId = String(newIdNum);
        mapping.set(id, newId);
      }
    }
    if (mapping.size === 0) return;

    // Reconstroi mapa de tutoriais com novos IDs
    const newMap = new Map<string, Tutorial>();
    for (const [oldId, tut] of Array.from(this.tutorials.entries())) {
      const newId = mapping.get(oldId) || oldId;
      const newTut = { ...tut, id: newId };
      newMap.set(newId, newTut);
    }
    this.tutorials = newMap;

    // Atualiza purchases referenciando tutoriais antigos
    if (this.purchases.size > 0) {
      for (const p of this.purchases.values()) {
        const newId = mapping.get(p.tutorial_id);
        if (newId) p.tutorial_id = newId;
      }
      await this.savePurchases();
    }

    await this.saveTutorials();
  }
}

export const store = new PersistentStore();