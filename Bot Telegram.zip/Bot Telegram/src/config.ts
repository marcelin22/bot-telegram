import dotenv from 'dotenv';
dotenv.config();

export const config = {
  botToken: process.env.BOT_TOKEN || '',
  groupChatId: process.env.GROUP_CHAT_ID || '',
  groupInviteLink: process.env.GROUP_INVITE_LINK || '',
  adminUserIds: (process.env.ADMIN_USER_IDS || '')
    .split(',')
    .map(s => s.trim().replace(/^["']|["']$/g, '')) // remove aspas
    .filter(Boolean),
  baseUrl: process.env.BASE_URL || '',
  pix: {
    baseUrl: process.env.PIX_PROVIDER_BASE_URL || '',
    apiKey: process.env.PIX_PROVIDER_API_KEY || '',
    webhookSecret: process.env.PIX_PROVIDER_WEBHOOK_SECRET || '',
    debug: (process.env.PIX_DEBUG === 'true' || process.env.PIX_DEBUG === '1')
  },
  port: Number(process.env.PORT || 3000),
  adminLoginSecret: process.env.ADMIN_LOGIN_SECRET || ''
};

if (!config.botToken) {
  console.warn('BOT_TOKEN não configurado!');
}