import axios from 'axios';
import { config } from '../config';

export interface CreateChargeInput {
  external_id: string;
  amount: number;
  description: string;
  metadata?: Record<string, any>;
}

export interface CreateChargeResponse {
  external_id: string;
  txid?: string;
  amount: number;
  qr_code_base64?: string;
  copy_paste?: string;
  qrcode?: string;
  pix?: { qrcode?: string; expiresInMinutes?: number };
  status: 'created' | 'pending';
  raw?: any;
}

export interface PaymentStatusResponse {
  external_id: string;
  txid?: string;
  amount: number;
  status: 'paid' | 'confirmed' | 'failed';
  paid_at?: string;
  raw?: any;
}

function generateCPF(): string {
  const rand = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min;
  const n1 = rand(0, 9);
  const n2 = rand(0, 9);
  const n3 = rand(0, 9);
  const n4 = rand(0, 9);
  const n5 = rand(0, 9);
  const n6 = rand(0, 9);
  const n7 = rand(0, 9);
  const n8 = rand(0, 9);
  const n9 = rand(0, 9);
  let d1 = n9 * 2 + n8 * 3 + n7 * 4 + n6 * 5 + n5 * 6 + n4 * 7 + n3 * 8 + n2 * 9 + n1 * 10;
  d1 = 11 - (d1 % 11);
  if (d1 >= 10) d1 = 0;
  let d2 = d1 * 2 + n9 * 3 + n8 * 4 + n7 * 5 + n6 * 6 + n5 * 7 + n4 * 8 + n3 * 9 + n2 * 10 + n1 * 11;
  d2 = 11 - (d2 % 11);
  if (d2 >= 10) d2 = 0;
  return `${n1}${n2}${n3}${n4}${n5}${n6}${n7}${n8}${n9}${d1}${d2}`;
}

export class PixProvider {
  private base = config.pix.baseUrl;
  private apiKey = config.pix.apiKey;

  async createCharge(input: CreateChargeInput): Promise<CreateChargeResponse> {
    const isPayoutbr = /payoutbr/i.test(this.base);
    const base = String(this.base || '').replace(/\/+$/,'');
    const url = isPayoutbr
      ? (base.endsWith('/transactions') ? base : `${base}/transactions`)
      : `${base}/charges`;
    const headers: Record<string, string> = { accept: 'application/json', 'content-type': 'application/json' };
    if (isPayoutbr) {
      const basic = Buffer.from(`${this.apiKey}:x`).toString('base64');
      headers['authorization'] = `Basic ${basic}`;
    } else {
      headers['Authorization'] = `Bearer ${this.apiKey}`;
    }
    
    const userId = String(input.metadata?.userId || '0');
    const username = (input.metadata?.username as string) || userId;
    const telegramName = (input.metadata?.telegramName as string) || username;
    
    // Formatar valor: multiplicar por 100 e converter para número inteiro
    const amountInCents = Math.round(input.amount * 100);
    
    const payload = isPayoutbr
      ? {
          customer: {
            document: {
              number: generateCPF(),
              type: 'cpf'
            },
            name: telegramName,
            email: `${username}@telegram.com`
          },
          items: [
            {
              tangible: true,
              title: input.description || 'Recarga',
              unitPrice: amountInCents,
              quantity: 1
            }
          ],
          amount: amountInCents,
          paymentMethod: 'pix'
        }
      : input;
    if (config.pix.debug) {
      console.log('[PIX] createCharge request', { url, auth: isPayoutbr ? 'Basic' : 'Bearer', payload });
    }
    try {
      const response = await axios.post(url, payload, { headers });
      const data = response.data;
      if (config.pix.debug) {
        console.log('[PIX] createCharge response', { status: response.status, data });
      }
      const code = (data?.pix?.qrcode)
        ?? data.copy_paste
        ?? data.qr_code
        ?? data.qrcode
        ?? data.qrCode
        ?? data.code
        ?? data.brcode;
      if (config.pix.debug) {
        console.log('[PIX] extracted qrcode', { qrcode: code });
      }
      return {
        external_id: data.external_id ?? data.id ?? input.external_id,
        txid: data.txid ?? data.transaction_id ?? data.id,
        amount: data.amount ?? input.amount,
        qr_code_base64: data.qr_code_base64 ?? data.qrcode_base64 ?? data.qrcode_image_base64 ?? data.encodedImage,
        copy_paste: code,
        qrcode: code,
        pix: { qrcode: code, expiresInMinutes: 10 },
        status: data.status ?? 'pending',
        raw: data
      };
    } catch (err: any) {
      if (config.pix.debug) {
        const status = err?.response?.status;
        const data = err?.response?.data;
        console.log('[PIX] createCharge error', { status, data, message: err?.message });
      }
      throw err;
    }
  }

  async getPaymentStatus(external_id: string): Promise<PaymentStatusResponse> {
    const isPayoutbr = /payoutbr/i.test(this.base);
    const base = String(this.base || '').replace(/\/+$/,'');
    const url = isPayoutbr
      ? (base.endsWith('/transactions')
          ? `${base}/${encodeURIComponent(external_id)}`
          : `${base}/transactions/${encodeURIComponent(external_id)}`)
      : `${base}/payments/${encodeURIComponent(external_id)}`;
    const headers: Record<string, string> = {};
    if (isPayoutbr) {
      const basic = Buffer.from(`${this.apiKey}:x`).toString('base64');
      headers['authorization'] = `Basic ${basic}`;
    } else {
      headers['Authorization'] = `Bearer ${this.apiKey}`;
    }
    if (config.pix.debug) {
      console.log('[PIX] getPaymentStatus request', { url, auth: isPayoutbr ? 'Basic' : 'Bearer' });
    }
    try {
      const response = await axios.get(url, { headers });
      const data = response.data;
      if (config.pix.debug) {
        console.log('[PIX] getPaymentStatus response', { status: response.status, data });
      }
      return {
        external_id: data.external_id ?? external_id,
        txid: data.txid ?? data.transaction_id ?? data.id,
        amount: data.amount,
        status: data.status,
        paid_at: data.paid_at,
        raw: data
      };
    } catch (err: any) {
      if (config.pix.debug) {
        const status = err?.response?.status;
        const data = err?.response?.data;
        console.log('[PIX] getPaymentStatus error', { status, data, message: err?.message });
      }
      throw err;
    }
  }

  async listTransactions(): Promise<any[]> {
    const isPayoutbr = /payoutbr/i.test(this.base);
    const base = String(this.base || '').replace(/\/+$/,'');
    const url = isPayoutbr ? (base.endsWith('/transactions') ? base : `${base}/transactions`) : `${base}/charges`;
    const headers: Record<string, string> = {};
    if (isPayoutbr) {
      const basic = Buffer.from(`${this.apiKey}:x`).toString('base64');
      headers['authorization'] = `Basic ${basic}`;
      headers['accept'] = 'application/json';
    } else {
      headers['Authorization'] = `Bearer ${this.apiKey}`;
    }
    if (config.pix.debug) {
      console.log('[PIX] listTransactions request', { url, auth: isPayoutbr ? 'Basic' : 'Bearer' });
    }
    const response = await axios.get(url, { headers });
    const data = response.data;
    if (config.pix.debug) {
      console.log('[PIX] listTransactions response', { status: response.status, count: Array.isArray(data) ? data.length : undefined });
    }
    return Array.isArray(data) ? data : (Array.isArray(data?.data) ? data.data : []);
  }
}

export const pixProvider = new PixProvider();