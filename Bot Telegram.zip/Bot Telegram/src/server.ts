import express from 'express';
import { config } from './config';
import { bot } from './bot';
import { store } from './store';
import { handlePixWebhook } from './pix';
import bodyParser from 'body-parser';

const app = express();
app.use(bodyParser.json({ type: '*/*' }));

function splitContent(content: string, chunkSize = 3500): string[] {
  const chunks: string[] = [];
  for (let i = 0; i < content.length; i += chunkSize) {
    chunks.push(content.slice(i, i + chunkSize));
  }
  return chunks;
}

// Telegram webhook opcional (usamos long-polling por padrão)
app.post('/webhook/telegram', (req, res) => {
  res.json({ ok: true });
});

// Webhook PIX
app.post('/webhook/pix', async (req, res) => {
  const secret = req.headers['x-webhook-secret'] || req.query.secret;
  if (config.pix.webhookSecret && secret !== config.pix.webhookSecret) {
    console.warn('Webhook PIX inválido.');
    return res.status(403).json({ ok: false });
  }
  const payload = req.body as {
    external_id: string; txid?: string; amount: number; status: string; paid_at?: string;
  };
  const result: any = await handlePixWebhook({
    external_id: payload.external_id,
    txid: payload.txid,
    amount: payload.amount,
    status: payload.status as any,
    paid_at: payload.paid_at
  });

  if (result.kind === 'add_balance') {
    const user = store.getUserById(result.userId!);
    if (user) {
      if (result.ok) {
        await bot.telegram.sendMessage(user.telegram_id, `Saldo creditado: R${result.amount}. Saldo atual: R${user.saldo}.`);
      } else {
        await bot.telegram.sendMessage(user.telegram_id, `Pagamento PIX não confirmado. Saldo não adicionado.`);
      }
    }
  } else if (result.ok && result.purchase) {
    const userId = result.purchase!.user_id;
    const user = store.getUserById(userId)!;
    await bot.telegram.sendMessage(user.telegram_id, `Pagamento confirmado ✅ — enviando seu conteúdo...`);
    for (const chunk of splitContent(result.content || '')) {
      await bot.telegram.sendMessage(user.telegram_id, chunk);
    }
  }

  res.json(result);
});

// WebApp simples para copiar código PIX para área de transferência
app.get('/webapp/copy', (req, res) => {
  const code = String(req.query.code || '').trim();
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.send(`<!doctype html><html lang="pt-br"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/><title>Copiar PIX</title><style>body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu;max-width:680px;margin:20px auto;padding:16px}code{display:block;white-space:pre-wrap;word-wrap:break-word;background:#f3f3f3;padding:12px;border-radius:8px}button{padding:12px 16px;border:none;border-radius:8px;background:#1d9bf0;color:#fff;font-weight:600;margin-top:12px}</style></head><body><h2>PIX Copia e Cola</h2><p>Toque em "Copiar" para colocar o código na área de transferência.</p><code id="code"></code><button id="btn">Copiar</button><p id="status"></p><script>
  const code = ${JSON.stringify(code)};
  const el = document.getElementById('code');
  const btn = document.getElementById('btn');
  const status = document.getElementById('status');
  el.textContent = code || 'Código indisponível';
  async function copyNow(){
    try { await navigator.clipboard.writeText(code); status.textContent = 'Copiado! Agora cole no seu app de banco.'; }
    catch(e){ status.textContent = 'Falha ao copiar. Selecione o texto manualmente e copie.'; }
  }
  btn.addEventListener('click', copyNow);
</script></body></html>`);
});

// Endpoint opcional de polling interno
app.post('/webhook/payment_check', async (req, res) => {
  const { external_id } = req.body;
  const { pollPixUntilConfirmed } = await import('./pix');
  const r = await pollPixUntilConfirmed(external_id);
  res.json(r);
});

app.get('/health', (_, res) => res.json({ ok: true }));

app.listen(config.port, async () => {
  console.log(`Server on :${config.port}`);
  // Long-polling do bot
  await bot.launch();
  console.log('Bot iniciado.');
});

// Graceful shutdown
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));